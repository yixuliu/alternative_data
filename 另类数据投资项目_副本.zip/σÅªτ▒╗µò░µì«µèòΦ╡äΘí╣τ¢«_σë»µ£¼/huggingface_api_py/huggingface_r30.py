from huggingface_hub import HfApi
from typing import List, Dict, Any

def get_stepfun_total_downloads(organization_id: str = "biomap-research") -> Dict[str, Any]:
    """
    通过 Hugging Face API 查询指定组织下所有模型的总下载量。
    """
    api = HfApi()
    total_downloads = 0
    
    try:
        # 1. 获取组织下的所有模型列表
        models_iterator = api.list_models(author=organization_id, limit=5000) # 增大limit确保覆盖所有模型
        
        models_data: List[Dict[str, Any]] = []
        
        # 2. 遍历模型并累加下载量
        for model in models_iterator:
            # 并非所有模型对象都直接包含所有下载量数据，需要重新查询或检查字段
            
            # 使用 model.modelId 获取模型的唯一标识符
            model_id = model.modelId
            
            # ⚠️ 注意：为了获取准确的 allTime 统计数据，通常需要对每个模型进行单独查询
            # 但基础的 list_models 结果中包含 downloads 字段 (通常是近 30 天的下载量)
            
            # 假设 model.downloads 字段包含近30天的下载量
            downloads_30d = getattr(model, 'downloads', 0)
            
            # 将模型的关键信息添加到列表中
            models_data.append({
                "model_id": model_id,
                "downloads_30d": downloads_30d,
                "likes": getattr(model, 'likes', 0)
            })
            
            total_downloads += downloads_30d
        
        # 3. 结果汇总
        return {
            "organization": organization_id,
            "total_models": len(models_data),
            "total_downloads_30d_approx": total_downloads,
            "models_list": models_data,
            "note": "Hugging Face API 的 Downloads 字段默认通常是过去30天的下载量。要获取'All Time'下载量需要额外的API调用或授权。"
        }
        
    except Exception as e:
        return {"Error": f"查询 Hugging Face 数据失败: {e}"}

# --- 运行示例 ---
if __name__ == "__main__":
    results = get_stepfun_total_downloads()
    
    import json
    print("\n--- StepFun AI Hugging Face 下载量分析 ---")
    print(json.dumps(results, ensure_ascii=False, indent=4))
    
    # 打印简要总结
    if "total_downloads_30d_approx" in results:
        print(f"\n💡 总结：")
        print(f"组织: {results['organization']}")
        print(f"总模型数量: {results['total_models']}")
        print(f"近 30 天总下载量 (估算): {results['total_downloads_30d_approx']:,}")