# Hugging Face API 工具

本目录包含用于查询 Hugging Face 模型数据的工具脚本。

## 📁 文件说明

### `huggingface_r30.py` - 组织模型下载量统计工具

**功能**：通过 Hugging Face API 查询指定组织下所有模型的近30天下载量统计。

**主要特性**：
- 查询指定组织下的所有模型列表
- 统计每个模型的近30天下载量和点赞数
- 计算组织下所有模型的总下载量
- 输出详细的模型列表和汇总信息

## 📦 依赖安装

```bash
pip install huggingface_hub
```

## 🚀 使用方法

### 基本使用

```bash
python huggingface_r30.py
```

默认查询组织：`biomap-research`

### 自定义组织

在代码中修改 `organization_id` 参数：

```python
results = get_stepfun_total_downloads(organization_id="your-org-name")
```

## 📊 输出格式

脚本会输出 JSON 格式的结果，包含：

- `organization`: 组织名称
- `total_models`: 模型总数
- `total_downloads_30d_approx`: 近30天总下载量（估算）
- `models_list`: 模型列表，每个模型包含：
  - `model_id`: 模型ID
  - `downloads_30d`: 近30天下载量
  - `likes`: 点赞数

## ⚠️ 注意事项

1. **下载量统计**：`downloads` 字段通常表示近30天的下载量，不是全时下载量
2. **API 限制**：`limit=5000` 已设置较大值，确保覆盖所有模型
3. **网络要求**：需要能够访问 Hugging Face API

## 📝 示例输出

```
--- StepFun AI Hugging Face 下载量分析 ---
{
    "organization": "biomap-research",
    "total_models": 10,
    "total_downloads_30d_approx": 12345,
    "models_list": [...]
}

💡 总结：
组织: biomap-research
总模型数量: 10
近 30 天总下载量 (估算): 12,345
```

