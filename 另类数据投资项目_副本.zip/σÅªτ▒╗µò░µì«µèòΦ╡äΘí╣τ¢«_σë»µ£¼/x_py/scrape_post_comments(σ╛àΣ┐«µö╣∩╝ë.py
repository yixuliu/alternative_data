#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简单的 X (Twitter) 帖子评论爬虫工具
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
import random
import os
import json
from datetime import datetime

def human_like_delay(min_sec=1, max_sec=4):
    """
    模拟人类行为的随机延迟
    
    Args:
        min_sec: 最小延迟秒数
        max_sec: 最大延迟秒数
    """
    delay = random.uniform(min_sec, max_sec)
    time.sleep(delay)

def check_login_status(driver):
    """
    检查是否已登录 X (Twitter)
    
    Returns:
        bool: 如果已登录返回 True，否则返回 False
    """
    try:
        # 检查是否存在登录相关的元素
        # 如果看到 "登录" 或 "Sign in" 按钮，说明未登录
        login_indicators = driver.find_elements(By.XPATH, 
            "//span[contains(text(), '登录') or contains(text(), 'Sign in')]")
        
        # 检查是否存在用户菜单或导航栏中的用户相关元素（登录后会有）
        user_indicators = driver.find_elements(By.CSS_SELECTOR, 
            "[data-testid='SideNav_AccountSwitcher_Button'], [aria-label*='Account menu']")
        
        if login_indicators and not user_indicators:
            return False
        return True
    except:
        return False

def wait_for_login(driver, timeout=300):
    """
    等待用户手动登录
    
    Args:
        driver: WebDriver 实例
        timeout: 超时时间（秒），默认5分钟
    
    Returns:
        bool: 登录是否成功
    """
    print("\n" + "="*80)
    print("⚠️  检测到未登录状态！")
    print("="*80)
    print("X (Twitter) 在未登录状态下会限制显示的内容，可能无法查看评论。")
    print("\n📍 登录位置：在自动打开的浏览器窗口中登录")
    print("\n请按照以下步骤操作：")
    print("1. 查看自动打开的 Chrome 浏览器窗口（应该已经打开了）")
    print("2. 在浏览器窗口中点击 '登录' 或 'Sign in' 按钮")
    print("3. 输入您的 X (Twitter) 账号和密码完成登录")
    print("4. 登录完成后，程序会自动检测并继续抓取（最多等待5分钟）")
    print("\n💡 提示：登录完成后，程序会自动检测，无需手动操作")
    print("="*80 + "\n")
    
    # 尝试跳转到登录页面（如果当前页面有登录按钮）
    try:
        login_buttons = driver.find_elements(By.XPATH, 
            "//a[contains(@href, '/i/flow/login')] | //a[contains(text(), '登录')] | //a[contains(text(), 'Sign in')]")
        if login_buttons:
            print("正在跳转到登录页面...")
            driver.execute_script("arguments[0].click();", login_buttons[0])
            time.sleep(2)
    except:
        pass
    
    start_time = time.time()
    check_interval = 3  # 每3秒检查一次
    last_prompt_time = 0
    
    while time.time() - start_time < timeout:
        if check_login_status(driver):
            print("\n✓ 检测到已登录，继续抓取...")
            time.sleep(2)  # 等待页面稳定
            return True
        
        time.sleep(check_interval)
        elapsed = int(time.time() - start_time)
        
        # 每10秒提示一次
        if elapsed - last_prompt_time >= 10:
            remaining = timeout - elapsed
            print(f"⏳ 等待登录中... (已等待 {elapsed} 秒，剩余 {remaining} 秒)")
            print("   提示：请在浏览器窗口中完成登录")
            last_prompt_time = elapsed
    
    print("\n⚠️  等待超时，将尝试继续抓取（可能结果不完整）")
    return False

def login_to_x(driver, username=None, password=None):
    """
    登录到 X (Twitter)
    
    Args:
        driver: Selenium WebDriver 实例
        username: 用户名或邮箱（如果为None，从环境变量或用户输入获取）
        password: 密码（如果为None，从环境变量或用户输入获取）
    
    Returns:
        bool: 登录是否成功
    """
    # 从环境变量获取凭据（如果未提供）
    if not username:
        username = os.getenv('X_USERNAME', '')
    if not password:
        password = os.getenv('X_PASSWORD', '')
    
    # 如果环境变量也没有，提示用户输入
    if not username:
        username = input("请输入 X (Twitter) 用户名或邮箱: ").strip()
    if not password:
        password = input("请输入密码: ").strip()
    
    try:
        print("\n🔐 开始登录 X (Twitter)...")
        print("正在打开登录页面...")
        
        # 访问登录页面
        driver.get("https://x.com/i/flow/login")
        human_like_delay(3, 5)
        
        # 等待并输入用户名
        print("正在输入用户名...")
        try:
            # 尝试多种可能的选择器
            username_selectors = [
                'input[autocomplete="username"]',
                'input[name="text"]',
                'input[type="text"]'
            ]
            
            username_input = None
            for selector in username_selectors:
                try:
                    username_input = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    if username_input:
                        break
                except:
                    continue
            
            if not username_input:
                raise Exception("无法找到用户名输入框")
            
            # 模拟人类输入（逐字符输入）
            username_input.clear()
            for char in username:
                username_input.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            human_like_delay(1, 2)
            
            # 点击下一步按钮
            try:
                next_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, 
                        "//span[contains(text(), 'Next') or contains(text(), '下一步')]/ancestor::div[@role='button']"))
                )
                next_button.click()
            except:
                # 尝试其他方式查找按钮
                try:
                    next_button = driver.find_element(By.XPATH, 
                        "//div[@role='button']//span[contains(text(), 'Next') or contains(text(), '下一步')]")
                    next_button.click()
                except:
                    print("⚠️  无法自动点击下一步按钮，请手动点击")
                    input("按回车继续...")
            human_like_delay(2, 3)
            
        except Exception as e:
            print(f"⚠️  输入用户名时出错: {e}")
            print("请手动完成登录，然后按回车继续...")
            input()
            return True  # 假设手动登录成功
        
        # 检查是否需要输入手机号（异常登录检测）
        try:
            phone_input = driver.find_element(By.CSS_SELECTOR, 'input[data-testid="ocfEnterTextTextInput"]')
            if phone_input:
                print("⚠️  X 要求验证手机号或邮箱")
                verification = input("请输入手机号或邮箱进行验证: ").strip()
                phone_input.send_keys(verification)
                human_like_delay(1, 2)
                
                try:
                    next_button = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, 
                            "//span[contains(text(), 'Next') or contains(text(), '下一步')]/ancestor::div[@role='button']"))
                    )
                    next_button.click()
                except:
                    try:
                        next_button = driver.find_element(By.XPATH, 
                            "//div[@role='button']//span[contains(text(), 'Next') or contains(text(), '下一步')]")
                        next_button.click()
                    except:
                        print("⚠️  无法自动点击下一步按钮，请手动点击")
                        input("按回车继续...")
                human_like_delay(2, 3)
        except:
            pass  # 不需要验证
        
        # 输入密码
        print("正在输入密码...")
        try:
            password_selectors = [
                'input[name="password"]',
                'input[type="password"]',
                'input[autocomplete="current-password"]'
            ]
            
            password_input = None
            for selector in password_selectors:
                try:
                    password_input = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    if password_input:
                        break
                except:
                    continue
            
            if not password_input:
                raise Exception("无法找到密码输入框")
            
            # 模拟人类输入密码
            password_input.clear()
            for char in password:
                password_input.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            human_like_delay(1, 2)
            
            # 点击登录按钮
            try:
                login_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, 
                        "//span[contains(text(), 'Log in') or contains(text(), '登录')]/ancestor::div[@role='button']"))
                )
                login_button.click()
            except:
                # 尝试其他方式查找按钮
                try:
                    login_button = driver.find_element(By.XPATH, 
                        "//div[@role='button']//span[contains(text(), 'Log in') or contains(text(), '登录')]")
                    login_button.click()
                except:
                    print("⚠️  无法自动点击登录按钮，请手动点击")
                    input("按回车继续...")
            human_like_delay(3, 5)
            
        except Exception as e:
            print(f"⚠️  输入密码时出错: {e}")
            print("请手动完成登录，然后按回车继续...")
            input()
            return True
        
        # 检查是否登录成功（通过检查是否跳转到主页或出现特定元素）
        try:
            # 等待页面加载，检查是否出现主页元素
            WebDriverWait(driver, 15).until(
                lambda d: "home" in d.current_url.lower() or 
                         d.find_elements(By.CSS_SELECTOR, '[data-testid="SideNav_AccountSwitcher_Button"]')
            )
            print("✅ 登录成功！")
            human_like_delay(2, 3)
            return True
        except TimeoutException:
            # 可能遇到验证码或其他验证
            print("⚠️  可能需要完成验证码或两步验证")
            print("请手动完成验证，然后按回车继续...")
            input()
            return True
        
    except Exception as e:
        print(f"❌ 登录过程出错: {e}")
        print("请手动完成登录，然后按回车继续...")
        input()
        return True  # 假设手动登录成功

def scrape_comments(post_url, login=True, require_login=True):
    """
    获取指定帖子的所有评论
    
    Args:
        post_url: 帖子URL，例如 https://x.com/ChainOpera_AI/status/1871027463456977401
        login: 是否先登录（默认True，未登录可能无法查看评论）
        require_login: 是否要求登录，默认True（如果未登录会等待用户手动登录）
    
    Returns:
        list: 评论列表，每个元素是包含评论信息的字典
    """
    # 设置 Chrome 选项
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    # 设置窗口大小，方便查看
    chrome_options.add_argument('--window-size=1920,1080')
    # 保持浏览器打开，方便调试
    # chrome_options.add_experimental_option("detach", True)
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # 先访问帖子页面
        print(f"\n正在访问: {post_url}")
        driver.get(post_url)
        print("浏览器窗口已打开，您可以查看操作过程...")
        human_like_delay(3, 5)  # 等待页面加载
        
        # 检查登录状态
        if login and require_login:
            if not check_login_status(driver):
                wait_for_login(driver)
            else:
                print("✓ 检测到已登录状态")
        
        # 重新访问帖子页面（登录后可能需要）
        print(f"\n正在访问目标帖子: {post_url}")
        driver.get(post_url)
        human_like_delay(3, 6)  # 等待页面加载，模拟人类阅读时间
        
        comments_dict = {}  # 使用字典去重，key是评论内容
        scroll_count = 0
        last_comment_count = 0
        no_new_comments_count = 0  # 连续没有新评论的次数
        
        print("\n开始滚动加载评论...")
        print("连续5次滚动没有新内容将自动停止")
        print("-" * 60)
        
        while True:
            # 查找所有评论元素
            comment_elements = driver.find_elements(By.CSS_SELECTOR, 
                '[data-testid="tweet"]')
            
            # 提取评论内容
            new_comments_this_round = 0
            for element in comment_elements:
                try:
                    # 获取评论文本
                    text_elements = element.find_elements(By.CSS_SELECTOR, 
                        '[data-testid="tweetText"]')
                    if text_elements:
                        comment_text = text_elements[0].text.strip()
                        if comment_text and comment_text not in comments_dict:
                            # 尝试获取用户名
                            username = "未知用户"
                            try:
                                user_elements = element.find_elements(By.CSS_SELECTOR, 
                                    '[data-testid="User-Name"]')
                                if user_elements:
                                    username = user_elements[0].text.split('\n')[0] if user_elements[0].text else "未知用户"
                            except:
                                pass
                            
                            # 尝试获取时间
                            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # 默认使用当前时间
                            try:
                                # 方法1: 查找time标签的datetime属性
                                time_elements = element.find_elements(By.TAG_NAME, "time")
                                if time_elements:
                                    datetime_attr = time_elements[0].get_attribute('datetime')
                                    if datetime_attr:
                                        # 解析ISO格式时间并转换为可读格式
                                        try:
                                            dt = datetime.fromisoformat(datetime_attr.replace('Z', '+00:00'))
                                            timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                                        except:
                                            # 如果解析失败，尝试其他格式
                                            try:
                                                dt = datetime.strptime(datetime_attr, "%Y-%m-%dT%H:%M:%S.%fZ")
                                                timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                                            except:
                                                pass
                                # 方法2: 如果time标签没有datetime，尝试获取文本内容
                                if timestamp == datetime.now().strftime("%Y-%m-%d %H:%M:%S") and time_elements:
                                    time_text = time_elements[0].text.strip()
                                    if time_text:
                                        timestamp = time_text
                            except:
                                pass
                            
                            comments_dict[comment_text] = {
                                '时间': timestamp,
                                '用户': username,
                                '具体评论': comment_text,
                                'index': len(comments_dict) + 1
                            }
                            new_comments_this_round += 1
                except:
                    continue
            
            # 检查是否有新评论
            if len(comments_dict) == last_comment_count:
                no_new_comments_count += 1
                if no_new_comments_count >= 5:  # 连续5次没有新评论，停止滚动
                    print(f"\n⚠️  连续 {no_new_comments_count} 次滚动没有新评论，已停止滚动并退出")
                    break
            else:
                no_new_comments_count = 0
            
            last_comment_count = len(comments_dict)
            
            # 模拟人类滚动：不是直接到底，而是渐进式滚动
            scroll_amount = random.randint(500, 1000)  # 每次滚动500-1000像素
            driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            
            scroll_count += 1
            
            # 输出进度信息
            if new_comments_this_round > 0:
                print(f"滚动 {scroll_count} 次 | 本次新增: {new_comments_this_round} 条 | 累计: {len(comments_dict)} 条评论")
            else:
                print(f"滚动 {scroll_count} 次 | 本次新增: 0 条 | 累计: {len(comments_dict)} 条评论 (连续 {no_new_comments_count} 次无新内容)")
            
            # 每次等待5秒
            time.sleep(5)
        
        # 转换为列表
        comments_list = list(comments_dict.values())
        
        print("-" * 60)
        print(f"\n✅ 滚动完成！")
        print(f"   总滚动次数: {scroll_count} 次")
        print(f"   找到评论数: {len(comments_list)} 条")
        print(f"   平均每次滚动: {len(comments_list)/scroll_count:.1f} 条评论" if scroll_count > 0 else "")
        
        return comments_list
        
    finally:
        driver.quit()

def main():
    # 示例：获取指定帖子的评论
    post_url = "https://x.com/ChainOpera_AI/status/1871027463456977401"
    
    print("=" * 60)
    print("X (Twitter) 评论爬虫工具")
    print("=" * 60)
    print("\n📝 输出说明:")
    print("   - 控制台：实时显示滚动进度和评论统计")
    print("   - comments.json：保存为JSON格式，包含时间、用户、具体评论三个字段")
    print("\n⏱️  行为模拟:")
    print("   - 每次滚动后等待 5 秒")
    print("   - 渐进式滚动（不是直接到底）")
    print("   - 连续5次滚动没有新内容将自动停止并退出")
    print("\n🔐 登录说明:")
    print("   - 默认会先检查登录状态（未登录可能无法查看评论）")
    print("   - 如果未登录，程序会等待您在浏览器窗口中手动登录")
    print("   - 登录完成后程序会自动检测并继续")
    print("\n📊 滚动50次预期:")
    print("   - 理论上可看到 500-1000+ 条评论")
    print("   - 实际取决于帖子的总评论数和X的加载机制")
    print("=" * 60)
    
    # 询问是否登录（默认登录）
    login_choice = input("\n是否需要登录？(Y/n，默认Y): ").strip().lower()
    need_login = login_choice != 'n'
    
    comments = scrape_comments(post_url, login=need_login, require_login=need_login)
    
    # 准备JSON数据（只包含需要的三个字段）
    json_data = {
        "帖子URL": post_url,
        "评论总数": len(comments),
        "抓取时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "评论列表": []
    }
    
    for comment in comments:
        json_data["评论列表"].append({
            "时间": comment['时间'],
            "用户": comment['用户'],
            "具体评论": comment['具体评论']
        })
    
    # 保存为JSON格式
    json_file = "comments.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(json_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 文件已保存:")
    print(f"   - {json_file} (JSON格式，包含：时间、用户、具体评论)")
    
    print("\n📋 前5条评论预览:")
    print("-" * 60)
    for comment in comments[:5]:
        print(f"\n【时间】{comment['时间']}")
        print(f"【用户】@{comment['用户']}")
        preview_text = comment['具体评论'][:150] + "..." if len(comment['具体评论']) > 150 else comment['具体评论']
        print(f"【评论】{preview_text}")

if __name__ == "__main__":
    main()

