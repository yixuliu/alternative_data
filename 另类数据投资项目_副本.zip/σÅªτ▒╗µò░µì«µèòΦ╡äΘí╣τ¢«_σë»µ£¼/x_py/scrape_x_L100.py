#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用 Selenium 抓取 X (Twitter) 主页上评论数大于100的帖子
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import time
import re

def check_login_status(driver):
    """
    检查是否已登录 X (Twitter)
    
    Returns:
        bool: 如果已登录返回 True，否则返回 False
    """
    try:
        # 检查是否存在登录相关的元素
        # 如果看到 "登录" 或 "Sign in" 按钮，说明未登录
        login_indicators = driver.find_elements(By.XPATH, 
            "//span[contains(text(), '登录') or contains(text(), 'Sign in')]")
        
        # 检查是否存在用户菜单或导航栏中的用户相关元素（登录后会有）
        user_indicators = driver.find_elements(By.CSS_SELECTOR, 
            "[data-testid='SideNav_AccountSwitcher_Button'], [aria-label*='Account menu']")
        
        if login_indicators and not user_indicators:
            return False
        return True
    except:
        return False

def wait_for_login(driver, timeout=300):
    """
    等待用户手动登录
    
    Args:
        driver: WebDriver 实例
        timeout: 超时时间（秒），默认5分钟
    """
    print("\n" + "="*80)
    print("⚠️  检测到未登录状态！")
    print("="*80)
    print("X (Twitter) 在未登录状态下会限制显示的内容，可能只能看到少量帖子。")
    print("\n📍 登录位置：在自动打开的浏览器窗口中登录")
    print("\n请按照以下步骤操作：")
    print("1. 查看自动打开的 Chrome 浏览器窗口（应该已经打开了）")
    print("2. 在浏览器窗口中点击 '登录' 或 'Sign in' 按钮")
    print("3. 输入您的 X (Twitter) 账号和密码完成登录")
    print("4. 登录完成后，程序会自动检测并继续抓取（最多等待5分钟）")
    print("\n💡 提示：登录完成后，程序会自动检测，无需手动操作")
    print("="*80 + "\n")
    
    # 尝试跳转到登录页面（如果当前页面有登录按钮）
    try:
        login_buttons = driver.find_elements(By.XPATH, 
            "//a[contains(@href, '/i/flow/login')] | //a[contains(text(), '登录')] | //a[contains(text(), 'Sign in')]")
        if login_buttons:
            print("正在跳转到登录页面...")
            driver.execute_script("arguments[0].click();", login_buttons[0])
            time.sleep(2)
    except:
        pass
    
    start_time = time.time()
    check_interval = 3  # 每3秒检查一次
    last_prompt_time = 0
    
    while time.time() - start_time < timeout:
        if check_login_status(driver):
            print("\n✓ 检测到已登录，继续抓取...")
            time.sleep(2)  # 等待页面稳定
            return True
        
        time.sleep(check_interval)
        elapsed = int(time.time() - start_time)
        
        # 每10秒提示一次
        if elapsed - last_prompt_time >= 10:
            remaining = timeout - elapsed
            print(f"⏳ 等待登录中... (已等待 {elapsed} 秒，剩余 {remaining} 秒)")
            print("   提示：请在浏览器窗口中完成登录")
            last_prompt_time = elapsed
    
    print("\n⚠️  等待超时，将尝试继续抓取（可能结果不完整）")
    return False

def scrape_x_posts(homepage_url, min_comments=100, require_login=True, max_scrolls=200):
    """
    抓取指定主页上评论数大于min_comments的帖子
    
    Args:
        homepage_url: X主页URL，例如 https://x.com/ChainOpera_AI
        min_comments: 最小评论数，默认100
        require_login: 是否要求登录，默认True
        max_scrolls: 最大滚动次数，默认100（如果连续3次没有新帖子会自动停止）
    """
    # 配置 Chrome 选项
    chrome_options = Options()
    # 注释掉 headless 模式，以便查看浏览器操作
    # chrome_options.add_argument('--headless')  # 无头模式，不显示浏览器窗口
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    # 设置窗口大小，方便查看
    chrome_options.add_argument('--window-size=1920,1080')
    
    driver = None
    try:
        # 初始化浏览器
        driver = webdriver.Chrome(options=chrome_options)
        
        # 先访问主页
        print(f"正在访问: {homepage_url}")
        driver.get(homepage_url)
        print("浏览器窗口已打开，您可以查看操作过程...")
        time.sleep(5)  # 等待页面加载
        
        # 检查登录状态
        if require_login:
            if not check_login_status(driver):
                wait_for_login(driver)
            else:
                print("✓ 检测到已登录状态")
        
        # 重新访问目标主页（登录后可能需要）
        print(f"\n正在访问目标主页: {homepage_url}")
        driver.get(homepage_url)
        time.sleep(3)  # 等待页面加载
        
        results = []
        seen_urls = set()
        scroll_count = 0
        no_new_posts_count = 0  # 连续没有新帖子的次数
        
        print(f"\n开始抓取帖子（最多滚动 {max_scrolls} 次，如果连续3次没有新帖子会自动停止）...")
        
        while scroll_count < max_scrolls:
            # 记录滚动前的帖子数量
            posts_before = len(seen_urls)
            
            # 查找所有帖子
            try:
                # X/Twitter 的帖子通常包含在 article 标签中
                articles = driver.find_elements(By.TAG_NAME, "article")
                print(f"当前页面找到 {len(articles)} 个 article 元素")
                
                for article in articles:
                    try:
                        # 查找帖子链接
                        link_elements = article.find_elements(By.CSS_SELECTOR, "a[href*='/status/']")
                        if not link_elements:
                            continue
                        
                        # 获取帖子URL
                        post_url = link_elements[0].get_attribute('href')
                        if not post_url or post_url in seen_urls:
                            continue
                        
                        # 查找评论数
                        # X/Twitter 评论按钮通常有 data-testid='reply'
                        comment_count = 0
                        
                        # 方法1: 从 aria-label 获取（最准确）
                        reply_buttons = article.find_elements(By.CSS_SELECTOR, 
                            "button[data-testid='reply'], div[data-testid='reply'], a[data-testid='reply']")
                        
                        for btn in reply_buttons:
                            try:
                                aria_label = btn.get_attribute('aria-label') or ''
                                # 匹配 "123 条回复" 或 "123 replies" 或 "123 回复" 或 "Reply"
                                match = re.search(r'(\d+[\d,]*)\s*(?:条回复|replies|回复|Reply)', aria_label, re.I)
                                if match:
                                    comment_count = int(match.group(1).replace(',', ''))
                                    break
                            except:
                                continue
                        
                        # 方法2: 如果方法1没找到，尝试从按钮的父元素或兄弟元素中查找数字
                        if comment_count == 0:
                            try:
                                # 查找回复按钮附近的文本
                                reply_container = article.find_elements(By.CSS_SELECTOR, 
                                    "[data-testid='reply']")
                                if reply_container:
                                    # 尝试获取父元素的文本
                                    parent = reply_container[0].find_element(By.XPATH, "./..")
                                    parent_text = parent.text
                                    # 查找数字
                                    numbers = re.findall(r'\b(\d+[\d,]*)\b', parent_text)
                                    for num_str in numbers:
                                        try:
                                            num = int(num_str.replace(',', ''))
                                            if 100 <= num < 1000000:
                                                comment_count = num
                                                break
                                        except:
                                            continue
                            except:
                                pass
                        
                        # 方法3: 如果前两种方法都没找到，尝试从整个 article 文本中查找
                        if comment_count == 0:
                            article_text = article.text
                            # 查找类似 "123" 这样的数字，通常在回复按钮附近
                            numbers = re.findall(r'\b(\d+[\d,]*)\b', article_text)
                            for num_str in numbers:
                                try:
                                    num = int(num_str.replace(',', ''))
                                    # 如果数字在合理范围内，可能是评论数
                                    if 100 <= num < 1000000:
                                        comment_count = num
                                        break
                                except:
                                    continue
                        
                        # 如果评论数大于阈值，添加到结果
                        if comment_count >= min_comments:
                            seen_urls.add(post_url)
                            results.append({
                                'url': post_url,
                                'comments': comment_count
                            })
                            print(f"✓ 找到帖子 ({len(results)}): {post_url} - 评论数: {comment_count}")
                        else:
                            # 即使评论数不够，也记录URL，用于统计
                            seen_urls.add(post_url)
                    
                    except Exception as e:
                        continue
                
                # 检查是否有新帖子
                posts_after = len(seen_urls)
                new_posts = posts_after - posts_before
                
                if new_posts == 0:
                    no_new_posts_count += 1
                    print(f"本次滚动未发现新帖子 (连续 {no_new_posts_count} 次)")
                    if no_new_posts_count >= 3:  # 连续3次没有新帖子，可能已经到底了
                        print("连续3次滚动未发现新帖子，可能已加载完所有内容")
                        break
                else:
                    no_new_posts_count = 0  # 重置计数器
                    print(f"本次滚动发现 {new_posts} 个新帖子，累计找到 {posts_after} 个帖子")
                
                # 滚动页面加载更多内容
                print(f"正在滚动页面 ({scroll_count + 1}/{max_scrolls})...")
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(3)  # 增加等待时间，确保内容加载
                scroll_count += 1
                
            except Exception as e:
                print(f"处理帖子时出错: {e}")
                break
        
        return results
    
    except Exception as e:
        print(f"错误: {e}")
        return []
    
    finally:
        if driver:
            driver.quit()

def main():
    # 示例：抓取 ChainOpera_AI 的主页
    homepage_url = "https://x.com/pika_labs"
    min_comments = 100
    max_scrolls = 100  # 最大滚动次数，可根据需要调整（如果连续3次没有新帖子会自动停止）
    
    print("=" * 80)
    print("X (Twitter) 帖子抓取工具")
    print("=" * 80)
    print(f"目标主页: {homepage_url}")
    print(f"最小评论数: {min_comments}")
    print(f"最大滚动次数: {max_scrolls} (如果连续3次没有新帖子会自动停止)")
    print("=" * 80)
    print("\n开始抓取 X (Twitter) 帖子...")
    print("提示: 如果未登录，程序会提示您手动登录以获得更多结果\n")
    
    results = scrape_x_posts(homepage_url, min_comments, require_login=True, max_scrolls=max_scrolls)
    
    print("\n" + "=" * 80)
    print(f"抓取完成！找到 {len(results)} 个评论数大于等于 {min_comments} 的帖子")
    print("=" * 80)
    
    if results:
        # 按评论数排序
        results_sorted = sorted(results, key=lambda x: x['comments'], reverse=True)
        
        print("\n帖子列表（按评论数降序）:")
        print("-" * 80)
        for i, result in enumerate(results_sorted, 1):
            print(f"{i}. URL: {result['url']}")
            print(f"   评论数: {result['comments']}")
            print("-" * 80)
        
        # 保存到文件
        output_file = "x_posts_results.txt"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"找到 {len(results)} 个评论数大于等于 {min_comments} 的帖子:\n")
            f.write("=" * 80 + "\n\n")
            for i, result in enumerate(results_sorted, 1):
                f.write(f"{i}. URL: {result['url']}\n")
                f.write(f"   评论数: {result['comments']}\n")
                f.write("-" * 80 + "\n")
        
        print(f"\n结果已保存到: {output_file}")
    else:
        print("\n⚠️  未找到符合条件的帖子")
        print("可能的原因:")
        print("1. 该账号没有评论数大于等于100的帖子")
        print("2. 未登录导致只能看到少量内容（建议登录后重试）")
        print("3. 页面加载不完整，可以增加滚动次数")

if __name__ == "__main__":
    main()

