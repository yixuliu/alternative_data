from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import random
import pandas as pd
import urllib.parse
import re # 引入正则表达式库，用于后续的 Authors_Raw 拆分
import os # 用于检查文件是否存在

# =================================================================
# ⚠️ 必须修改：您的 ChromeDriver 路径！
# 示例：'/usr/local/bin/chromedriver' 或 'C:\\Drivers\\chromedriver.exe'
CHROMEDRIVER_PATH = '/opt/homebrew/bin/chromedriver' 
# =================================================================


# --- 爬虫配置参数 ---
# 🌟 支持多关键词和布尔逻辑（请在英文模式下使用 OR, AND）
SEARCH_KEYWORD =  "Domain-Adaptive Pre-training"
MAX_PAGES = 110                               # 抓取的最大页数 (10页约100条结果)
START_YEAR = 2024                              # 筛选起始年份
END_YEAR = 2024                               # 筛选结束年份（设为 None 则不限制结束年份）
OUTPUT_FILE = 'dapt_Candidates_Raw2024.csv'        # 输出文件名


def setup_browser(headless=True):
    """
    配置并启动 Chrome 浏览器实例，使用指定的驱动路径。
    """
    options = Options()
    
    # 无头模式配置
    if headless:
        options.add_argument('--headless=new')
        options.add_argument('--window-size=1920,1080')
    
    # 反爬伪装参数
    options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    # 启动 WebDriver，使用指定的本地路径
    service = ChromeService(executable_path=CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=options)
    
    return driver

def introduce_random_delay(min_sec=5, max_sec=10):
    """引入随机延迟，模拟人类行为"""
    delay = random.uniform(min_sec, max_sec)
    print(f"💤 延迟 {delay:.2f} 秒...")
    time.sleep(delay)

def load_existing_data(file_path):
    """
    加载已存在的CSV文件数据，用于去重
    返回：(DataFrame, set) - 数据框和已存在的(标题,作者)元组集合
    """
    if os.path.exists(file_path):
        try:
            df = pd.read_csv(file_path, encoding='utf-8-sig')
            existing_tuples = set(zip(df['Title'].astype(str), df['Authors_Raw'].astype(str)))
            print(f"📂 检测到已有文件，已加载 {len(df)} 条记录用于去重")
            return df, existing_tuples
        except Exception as e:
            print(f"⚠️ 读取已有文件时出错: {e}，将创建新文件")
            return pd.DataFrame(), set()
    return pd.DataFrame(), set()

def append_to_csv(data_list, file_path, existing_tuples):
    """
    将新数据追加写入CSV文件（边抓取边写入）
    data_list: 新抓取的数据列表
    file_path: CSV文件路径
    existing_tuples: 已存在的(标题,作者)元组集合，用于去重
    返回: 实际写入的新数据条数
    """
    if not data_list:
        return 0
    
    # 去重：过滤掉已存在的数据
    new_data = []
    for item in data_list:
        title = str(item.get('Title', ''))
        authors = str(item.get('Authors_Raw', ''))
        if (title, authors) not in existing_tuples:
            new_data.append(item)
            existing_tuples.add((title, authors))  # 添加到已存在集合中
    
    if not new_data:
        print(f"   ⚠️ 本页数据全部重复，跳过写入")
        return 0
    
    # 创建DataFrame
    df_new = pd.DataFrame(new_data)
    
    # 检查文件是否存在
    file_exists = os.path.exists(file_path)
    
    # 追加写入（mode='a'表示追加，header=False表示不写表头）
    df_new.to_csv(file_path, mode='a', header=not file_exists, 
                  index=False, encoding='utf-8-sig')
    
    return len(new_data)

def check_for_captcha(driver):
    """检查是否遇到 CAPTCHA 验证"""
    page_source = driver.page_source.lower()
    current_url = driver.current_url.lower()
    
    captcha_indicators = [
        'captcha' in page_source,
        'sorry' in current_url,
        'sorry' in page_source,
        'unusual traffic' in page_source,
        'robot' in page_source and 'verify' in page_source
    ]
    
    return any(captcha_indicators)

def wait_for_captcha_completion(driver, headless_mode=False, max_wait_time=300, check_interval=5):
    """
    等待用户手动完成 CAPTCHA 验证
    headless_mode: 是否为无头模式
    max_wait_time: 最大等待时间（秒），默认5分钟
    check_interval: 检查间隔（秒），默认5秒检查一次
    """
    if headless_mode:
        print("\n💡 提示：由于是无头模式，无法手动完成验证。")
        print("   请修改代码中的 HEADLESS_MODE = False 后重新运行。")
        driver.quit()
        return False
    
    print("\n⏳ 正在等待您手动完成验证...")
    print("   💡 请切换到浏览器窗口完成验证，完成后程序会自动继续")
    print(f"   ⏱ 最多等待 {max_wait_time} 秒...")
    
    start_time = time.time()
    check_count = 0
    
    while time.time() - start_time < max_wait_time:
        time.sleep(check_interval)
        check_count += 1
        
        # 检查验证是否已完成（通过检查是否不再是验证页面来判断）
        if not check_for_captcha(driver):
            # 再等待一下，确保页面完全加载
            time.sleep(2)
            # 尝试检查是否有搜索结果，确认页面正常
            try:
                driver.find_element(By.TAG_NAME, 'body')
                print(f"\n✅ 验证已完成！程序将继续运行...")
                return True
            except:
                pass
        
        # 每30秒提示一次
        if check_count % 6 == 0:
            elapsed = int(time.time() - start_time)
            remaining = max_wait_time - elapsed
            print(f"   ⏳ 仍在等待验证完成... 已等待 {elapsed} 秒，剩余约 {remaining} 秒")
    
    print(f"\n⏰ 等待超时（{max_wait_time} 秒），验证可能未完成")
    return False

def scrape_page_data(driver):
    """从当前页面提取论文数据"""
    data_list = []
    
    # **【诊断步骤 1】** 检查是否遇到 CAPTCHA
    if check_for_captcha(driver):
        print("🚨 检测到 CAPTCHA 验证页面！")
        print(f"   当前 URL: {driver.current_url}")
        # 保存截图以便调试
        try:
            driver.save_screenshot('captcha_detected.png')
            print("   💾 已保存截图: captcha_detected.png")
        except:
            pass
        return data_list
    
    # **【诊断步骤 2】** 增加等待时间并添加详细诊断
    try:
        print("   ⏳ 等待搜索结果加载...")
        # 先等待页面基本加载（body 标签出现）
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.TAG_NAME, 'body'))
        )
        
        # 再等待搜索结果出现（增加等待时间到 20 秒）
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'gs_ri'))
        )
        print("   ✅ 搜索结果已加载")
    except TimeoutException:
        print("⚠️ 等待页面加载超时，可能遇到 CAPTCHA 或网络问题")
        print(f"   当前 URL: {driver.current_url}")
        print(f"   页面标题: {driver.title}")
        
        # **【诊断步骤 3】** 尝试查找其他可能的元素来判断页面状态
        try:
            # 检查是否有"没有找到结果"的提示
            no_results = driver.find_elements(By.XPATH, "//*[contains(text(), '未找到') or contains(text(), 'did not match') or contains(text(), 'No articles')]")
            if no_results:
                print("   📝 页面提示：没有找到匹配的结果")
                return data_list
            
            # 检查是否有搜索结果容器
            gs_results = driver.find_elements(By.ID, 'gs_res_ccl_mid')
            if gs_results:
                print(f"   📦 找到搜索结果容器，但未找到具体结果元素")
            
            # 保存页面源码的片段用于调试
            page_preview = driver.page_source[:500] if len(driver.page_source) > 500 else driver.page_source
            print(f"   页面内容预览（前500字符）: {page_preview[:200]}...")
            
        except Exception as e:
            print(f"   诊断检查时出错: {e}")
        
        # 保存截图以便调试
        try:
            driver.save_screenshot('timeout_page.png')
            print("   💾 已保存截图: timeout_page.png，请检查是否遇到 CAPTCHA")
        except:
            pass
        
        return data_list
    
    # 找到所有论文结果区块
    results = driver.find_elements(By.CLASS_NAME, 'gs_ri')
    print(f"   找到 {len(results)} 条结果")
    
    for result in results:
        try:
            # 1. 标题和链接
            title_element = result.find_element(By.CSS_SELECTOR, 'h3.gs_rt a')
            title = title_element.text
            link = title_element.get_attribute('href')
            
            # 2. 原始作者信息行 (Authors_Raw, 包含作者、年份、机构)
            authors_info_raw = result.find_element(By.CLASS_NAME, 'gs_a').text.strip()
            
            # 3. 引用次数（改进提取逻辑，使用多种策略）
            citations = 0
            try:
                # 策略1: 查找包含"Cited by"或"被引用"的链接元素（最准确）
                citation_elements = result.find_elements(By.XPATH, 
                    ".//a[contains(text(), 'Cited by') or contains(text(), '被引用')]")
                
                if citation_elements:
                    citation_text = citation_elements[0].text
                    # 提取数字
                    citation_match = re.search(r'(\d+)', citation_text.replace(',', ''))
                    if citation_match:
                        citations = int(citation_match.group(1))
                
                # 策略2: 如果策略1失败，尝试从整个 gs_fl div 中提取
                if citations == 0:
                    citation_div = result.find_element(By.CSS_SELECTOR, 'div.gs_fl')
                    citation_text = citation_div.text
                    # 匹配多种格式：Cited by 123, 被引用 123, Cited by: 123 等
                    citation_match = re.search(r'(?:Cited by|被引用)[：:\s]*([\d,]+)', citation_text, re.I)
                    if citation_match:
                        citations = int(citation_match.group(1).replace(',', ''))
                    else:
                        # 如果没有明确的标识，尝试查找所有数字（可能是引用数）
                        numbers = re.findall(r'\b\d{1,3}(?:,\d{3})*\b', citation_text)
                        if numbers:
                            # 通常第一个大数字是引用数
                            citations = int(numbers[0].replace(',', ''))
                
            except Exception as e:
                # 如果所有方法都失败，保持为 0
                citations = 0
            
            # 4. 摘要片段 (Snippet)
            try:
                snippet = result.find_element(By.CLASS_NAME, 'gs_rs').text.strip()
            except NoSuchElementException:
                snippet = ""
            
            data_list.append({
                'Title': title,
                'Authors_Raw': authors_info_raw,
                'Citations': citations,
                'Link': link,
                'Snippet': snippet
            })
        except NoSuchElementException:
            # 忽略无法找到关键元素的条目，可能是广告或特殊格式
            continue
        except Exception as e:
            # 捕获其他异常
            # print(f"抓取单个结果时发生错误: {e}")
            continue
            
    return data_list

def run_scraper():
    """执行完整的抓取流程（边抓取边写入）"""
    if CHROMEDRIVER_PATH == 'YOUR_CHROMEDRIVER_PATH':
        print("🚨 错误：请先将代码中的 CHROMEDRIVER_PATH 替换为您的实际路径！")
        return

    # 🌟 加载已有数据用于去重（支持断点续传）
    existing_df, existing_tuples = load_existing_data(OUTPUT_FILE)
    total_saved = len(existing_df)  # 已保存的总数
    
    # 🌟 关键词 URL 编码：确保多关键词和布尔逻辑可以被正确传递
    search_query_encoded = urllib.parse.quote_plus(SEARCH_KEYWORD)
    # 构建年份筛选参数
    year_params = f"as_ylo={START_YEAR}"
    if END_YEAR is not None:
        year_params += f"&as_yhi={END_YEAR}"
    initial_url = f"https://scholar.google.com/scholar?hl=zh-CN&q={search_query_encoded}&{year_params}"
    
    # 启动浏览器 
    # **【改进】** 允许切换无头模式（设为 False 可看到浏览器窗口，便于调试）
    HEADLESS_MODE = False  # 如果遇到问题，可以改为 False 以便观察
    
    try:
        driver = setup_browser(headless=HEADLESS_MODE)
        print(f"🌐 正在访问: {initial_url}")
        driver.get(initial_url)
        
        # **【改进】** 等待初始页面加载（增加等待时间）
        print("⏳ 等待初始页面加载...")
        time.sleep(5)  # 增加初始等待时间
        
        # **【改进】** 更全面的 CAPTCHA 检查
        if check_for_captcha(driver):
            print("🚨 警告：检测到 CAPTCHA 验证页面！")
            try:
                driver.save_screenshot('initial_captcha.png')
                print("   💾 已保存截图: initial_captcha.png")
            except:
                pass
            
            # 等待用户手动完成验证
            if not wait_for_captcha_completion(driver, headless_mode=HEADLESS_MODE):
                print("❌ 验证未完成或超时，程序退出")
                driver.quit()
                return
            
            # 验证完成后，重新检查页面是否正常
            print("   🔍 重新检查页面状态...")
            time.sleep(2)
            if check_for_captcha(driver):
                print("   ⚠️ 验证可能仍未完成，程序将继续尝试...")
        
        # 检查页面是否正常加载
        print(f"   页面标题: {driver.title}")
        print(f"   当前 URL: {driver.current_url}")
        
    except Exception as e:
        print(f"❌ 启动浏览器或访问初始页面失败，请检查 ChromeDriver 路径和版本是否匹配您的 Chrome 浏览器。\n错误信息: {e}")
        return

    current_page = 1
    
    while current_page <= MAX_PAGES:
        print(f"\n--- 正在抓取第 {current_page} 页，已保存 {total_saved} 条记录 ---")
        
        try:
            # 1. 抓取当前页数据
            page_data = scrape_page_data(driver)
            print(f"   本页抓取 {len(page_data)} 条")
            
            # 2. 立即写入CSV文件（边抓取边写入）
            if page_data:
                new_count = append_to_csv(page_data, OUTPUT_FILE, existing_tuples)
                total_saved += new_count
                print(f"   💾 已写入 {new_count} 条新数据，总计已保存 {total_saved} 条")
            else:
                print(f"   ⚠️ 本页未抓取到数据")
            
            # 如果已经是最后一页，就不需要找下一页按钮了
            if current_page >= MAX_PAGES:
                print(f"✅ 已达到最大页数限制 ({MAX_PAGES} 页)")
                break
            
            # 2. 尝试定位并点击下一页（优化后的更强定位策略）
            try:
                # **【优化点 1：先等待页面稳定】** 给页面一些时间完全加载
                time.sleep(2)
                
                # **【优化点 2：多种定位策略】** 尝试多种方式找到下一页按钮
                next_button = None
                
                # 策略1: CSS选择器（最简单）
                try:
                    print("   🔍 尝试定位下一页按钮（CSS选择器）...")
                    WebDriverWait(driver, 30).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, 'button.gs_btnPR'))
                    )
                    next_button = driver.find_element(By.CSS_SELECTOR, 'button.gs_btnPR')
                    print("   ✅ 找到下一页按钮（CSS选择器）")
                except TimeoutException:
                    # 策略2: XPath定位（兼容性更强）
                    try:
                        print("   🔍 尝试定位下一页按钮（XPath）...")
                        next_button_xpath = '//button[contains(@class, "gs_btnPR")]'
                        WebDriverWait(driver, 30).until(
                            EC.presence_of_element_located((By.XPATH, next_button_xpath))
                        )
                        next_button = driver.find_element(By.XPATH, next_button_xpath)
                        print("   ✅ 找到下一页按钮（XPath）")
                    except TimeoutException:
                        print("   ❌ 无法找到下一页按钮")
                        raise TimeoutException("未找到下一页按钮")

                # 检查按钮是否被禁用（代表到达最后一页）
                button_html = next_button.get_attribute('outerHTML')
                is_disabled = 'disabled' in button_html or not next_button.is_enabled()
                
                if is_disabled:
                    print("   🏁 已到达最后一页或按钮被禁用。")
                    print(f"   按钮状态: {button_html[:100]}...")
                    break
                
                # **【优化点 3：保存旧结果引用，用于检测页面刷新】** 
                # 获取当前页面的第一个结果元素作为标记
                try:
                    old_result = driver.find_element(By.CLASS_NAME, 'gs_ri')
                except:
                    old_result = None
                
                # 3. 点击下一页
                print("   👆 点击下一页...")
                # 使用JavaScript点击，更可靠
                try:
                    driver.execute_script("arguments[0].click();", next_button)
                except:
                    next_button.click()
                
                # **【优化点 4：强制等待新结果加载】** 等待旧的搜索结果消失，确保页面已刷新
                print("   ⏳ 等待新页面加载...")
                if old_result:
                    try:
                        WebDriverWait(driver, 20).until(
                            EC.staleness_of(old_result)  # 等待旧结果消失
                        )
                        print("   ✅ 检测到页面已刷新（旧结果消失）")
                    except TimeoutException:
                        # 如果旧结果没有消失，等待新结果出现作为替代验证
                        print("   ⏳ 等待新搜索结果出现...")
                        WebDriverWait(driver, 20).until(
                            EC.presence_of_element_located((By.CLASS_NAME, 'gs_ri'))
                        )
                        print("   ✅ 新搜索结果已加载")
                else:
                    # 如果没有找到旧结果，直接等待新结果出现
                    print("   ⏳ 等待新搜索结果出现...")
                    WebDriverWait(driver, 20).until(
                        EC.presence_of_element_located((By.CLASS_NAME, 'gs_ri'))
                    )
                    print("   ✅ 新搜索结果已加载")
                
                # 额外等待，确保页面完全稳定
                time.sleep(2)
                
                # 引入延迟，模拟人类行为
                introduce_random_delay(min_sec=3, max_sec=6) 
                current_page += 1
                print(f"   ✅ 成功翻页到第 {current_page} 页")
                
            except TimeoutException as e:
                # 如果等待超时，通常是到达最后一页或 CAPTCHA 阻拦
                print("❌ 等待下一页按钮超时（可能到达最后一页或遇到 CAPTCHA）。")
                print(f"   当前 URL: {driver.current_url}")
                
                # 检查是否遇到验证
                if check_for_captcha(driver):
                    print("🚨 检测到验证页面，等待您手动完成验证...")
                    try:
                        screenshot_name = f'error_page_{current_page}_timeout.png'
                        driver.save_screenshot(screenshot_name)
                        print(f"   💾 已保存截图: {screenshot_name}")
                    except:
                        pass
                    
                    # 等待用户完成验证
                    if wait_for_captcha_completion(driver, headless_mode=HEADLESS_MODE):
                        print("   ✅ 验证已完成，继续尝试翻页...")
                        continue  # 重试当前页
                    else:
                        print("   ❌ 验证未完成，退出程序")
                        break
                
                # 尝试截图保存当前页面状态
                try:
                    screenshot_name = f'error_page_{current_page}_timeout.png'
                    driver.save_screenshot(screenshot_name)
                    print(f"   💾 已保存截图: {screenshot_name}")
                    
                    # 尝试查找是否有下一页按钮（即使被禁用）
                    try:
                        buttons = driver.find_elements(By.CSS_SELECTOR, 'button.gs_btnPR')
                        if buttons:
                            button_html = buttons[0].get_attribute('outerHTML')
                            print(f"   🔍 找到按钮，状态: {button_html[:200]}...")
                        else:
                            print("   🔍 未找到任何下一页按钮元素")
                    except:
                        print("   🔍 无法检查按钮状态")
                except Exception as screenshot_error:
                    print(f"   ⚠️ 保存截图失败: {screenshot_error}")
                break
                
        except NoSuchElementException as e:
            # 找不到关键元素，可能是页面结构变化或遇到 CAPTCHA
            print(f"⚠️ 页面结构异常，找不到预期元素。可能是 CAPTCHA 或页面结构变化。\n错误: {e}")
            print(f"   当前 URL: {driver.current_url}")
            
            # 检查是否遇到验证
            if check_for_captcha(driver):
                print("🚨 检测到验证页面，等待您手动完成验证...")
                if wait_for_captcha_completion(driver, headless_mode=HEADLESS_MODE):
                    print("   ✅ 验证已完成，继续抓取...")
                    continue  # 重试当前页
                else:
                    print("   ❌ 验证未完成，退出程序")
                    break
            else:
                break
                
        except Exception as e:
            # 捕获其他异常，如连接中断或 CAPTCHA
            print(f"❌ 抓取中断，可能遇到 CAPTCHA 或连接错误。\n错误信息: {e}")
            print(f"   当前 URL: {driver.current_url}")
            
            # 检查是否遇到验证
            if check_for_captcha(driver):
                print("🚨 检测到验证页面，等待您手动完成验证...")
                try:
                    driver.save_screenshot(f'error_page_{current_page}.png')
                    print("   已保存错误页面截图")
                except:
                    pass
                
                if wait_for_captcha_completion(driver, headless_mode=HEADLESS_MODE):
                    print("   ✅ 验证已完成，继续抓取...")
                    continue  # 重试当前页
                else:
                    print("   ❌ 验证未完成，退出程序")
                    break
            
            # 尝试截图保存（如果有错误）
            try:
                driver.save_screenshot(f'error_page_{current_page}.png')
                print("   已保存错误页面截图")
            except:
                pass
            break
            
    driver.quit()
    
    # --- 数据后处理与统计（边写入模式下，数据已实时保存）---
    if not os.path.exists(OUTPUT_FILE):
        print("🚨 没有抓取到任何数据，请检查关键词或是否被 CAPTCHA 阻拦。")
        return
    
    # 读取最终保存的数据进行统计
    try:
        df = pd.read_csv(OUTPUT_FILE, encoding='utf-8-sig')
        
        # 去重（虽然边写入时已去重，但这里再次确保）
        df = df.drop_duplicates(subset=['Title', 'Authors_Raw'])
        
        # 确保 Citations 字段是数值类型，然后排序
        try:
            df['Citations'] = pd.to_numeric(df['Citations'], errors='coerce')
            df = df.sort_values(by='Citations', ascending=False).reset_index(drop=True)
        except Exception as e:
            print(f"⚠️ 引用量排序失败，使用原始顺序。\n错误信息: {e}")
        
        # 保存排序后的结果（覆盖原文件）
        df.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')
        
        print(f"\n📊 最终数据统计：")
        print(f"   总记录数: {len(df)}")
        print(f"   有引用次数的记录: {len(df[df['Citations'] > 0])}")
        print(f"   无引用次数的记录: {len(df[df['Citations'] == 0])}")
        
        # 显示排序后的前几条记录
        if len(df) > 0:
            print(f"\n📈 按引用次数排序后的前 10 条记录：")
            print("=" * 80)
            for idx, row in df.head(10).iterrows():
                citations = row['Citations'] if pd.notna(row['Citations']) else 0
                print(f"{idx+1}. [{int(citations)} 次引用] {row['Title'][:60]}...")
        
        print(f"\n✅ 数据抓取完成！结果已保存到 {OUTPUT_FILE}")
        print(f"共保存 {len(df)} 条不重复的记录，已按引用次数从高到低排序。")
        
    except Exception as e:
        print(f"⚠️ 读取最终数据时出错: {e}")
        print(f"但数据已实时保存到 {OUTPUT_FILE}，请手动检查文件。")

if __name__ == '__main__':
    run_scraper()