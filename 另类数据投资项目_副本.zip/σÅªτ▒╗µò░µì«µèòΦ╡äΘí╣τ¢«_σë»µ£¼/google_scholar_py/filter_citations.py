import pandas as pd

# 读取CSV文件
df = pd.read_csv('datp_raw_data.csv')

# 筛选 Citations > 7 的行
df_filtered = df[df['Citations'] > 50]

# 保存为新文件
df_filtered.to_csv('dapt_raw_data_l50.csv', index=False)

print(f"✅ 筛选完成！原始数据 {len(df)} 行，筛选后 {len(df_filtered)} 行（Citations > 7）")
