# Google Scholar 爬虫与数据处理工具集

本目录包含一套完整的 Google Scholar 论文爬取、作者信息提取和数据处理工具链。

## 📁 文件说明

### 1. `00gs_citation_crawler.py` - Google Scholar 引用爬虫

**功能**：根据关键词搜索 Google Scholar 论文，爬取论文的标题、作者、引用次数、摘要等信息，并支持年份筛选。

**主要特性**：
- 支持关键词搜索（支持多关键词和布尔逻辑：OR、AND）
- 支持年份范围筛选（`START_YEAR` 和 `END_YEAR`）
- 自动翻页获取多页结果
- 自动去重（基于标题和作者）
- 边爬取边写入 CSV 文件（支持断点续传）
- 自动检测和处理 CAPTCHA 验证
- 按引用次数自动排序

**配置参数**（在文件顶部修改）：
```python
CHROMEDRIVER_PATH = '/opt/homebrew/bin/chromedriver'  # ChromeDriver 路径
SEARCH_KEYWORD = "Domain-Adaptive Pre-training"       # 搜索关键词
MAX_PAGES = 110                                        # 最大爬取页数
START_YEAR = 2024                                      # 起始年份
END_YEAR = 2024                                       # 结束年份（None 则不限制）
OUTPUT_FILE = 'dapt_Candidates_Raw2024.csv'           # 输出文件名
```

**使用方法**：
```bash
python 00gs_citation_crawler.py
```

**输出文件**：`{OUTPUT_FILE}`（CSV 格式）

**输出字段**：
- `Title`: 论文标题
- `Authors_Raw`: 作者信息（原始格式，包含作者、年份、机构）
- `Citations`: 引用次数
- `Link`: 论文链接
- `Snippet`: 摘要片段

**注意事项**：
- 必须配置正确的 ChromeDriver 路径
- 建议将 `HEADLESS_MODE` 设为 `False` 以便观察和手动处理验证码
- 遇到 CAPTCHA 时会自动等待用户手动完成验证
- 支持断点续传，如果程序中断，重新运行会跳过已爬取的数据

---

### 2. `gs_homepage_url.py` - 作者主页 URL 提取工具

**功能**：从包含论文标题的 CSV 文件中读取数据，自动搜索每篇论文并提取所有有 Google Scholar 主页的作者及其主页 URL。

**主要特性**：
- 自动搜索论文并提取作者主页链接
- 支持断点续传（跳过已处理的论文）
- 边处理边写入 CSV 文件
- 自动处理验证码和访问限制

**配置参数**（在 `main()` 函数中修改）：
```python
INPUT_CSV = '/path/to/input.csv'           # 输入 CSV 文件（需包含 Title 列）
OUTPUT_CSV = '/path/to/output.csv'        # 输出 CSV 文件
DRIVER_PATH = None                         # ChromeDriver 路径（None 则使用系统 PATH）
HEADLESS_MODE = False                      # 是否使用无头模式
```

**使用方法**：
```bash
python gs_homepage_url.py
```

**输入文件要求**：
- 必须包含 `Title` 列（不区分大小写）
- CSV 格式，UTF-8 编码

**输出文件**：`{OUTPUT_CSV}`（CSV 格式）

**输出字段**：
- `paper_title`: 论文标题
- `author_name`: 作者姓名
- `homepage_url`: Google Scholar 主页 URL

**注意事项**：
- 如果某篇论文没有找到作者主页，会记录论文标题但 `author_name` 和 `homepage_url` 为空
- 支持断点续传，重新运行会跳过已处理的论文
- 建议使用可见模式（`HEADLESS_MODE = False`）以避免被检测

---

### 3. `gs_homepage_detail.py` - 作者主页详情爬虫

**功能**：从包含 Google Scholar 主页 URL 的 CSV 文件中读取 URL，爬取每个作者的详细信息（姓名、机构、邮箱、研究领域、引用指标、著作列表、合作者等）。

**主要特性**：
- 提取作者完整信息
- 支持断点续传（跳过已处理的 URL）
- 边爬取边写入 CSV 文件
- 自动提取著作列表（JSON 格式）
- 自动提取合作者列表（JSON 格式）

**配置参数**（在 `main()` 函数中修改）：
```python
INPUT_CSV = '/path/to/input.csv'           # 输入 CSV 文件（需包含 homepage_url 列）
OUTPUT_CSV = '/path/to/output.csv'        # 输出 CSV 文件
DRIVER_PATH = None                         # ChromeDriver 路径
HEADLESS_MODE = False                      # 是否使用无头模式
```

**使用方法**：
```bash
python gs_homepage_detail.py
```

**输入文件要求**：
- 必须包含 `homepage_url` 列（或包含 "url" 或 "homepage" 的列名）
- CSV 格式，UTF-8 编码

**输出文件**：`{OUTPUT_CSV}`（CSV 格式）

**输出字段**：
- `homepage_url`: Google Scholar 主页 URL
- `name`: 作者姓名
- `affiliation`: 任职单位/机构
- `verified_email`: 验证邮箱
- `homepage_link`: 个人主页链接
- `research_interests`: 研究领域/兴趣（分号分隔）
- `publications`: 著作列表（JSON 字符串格式，包含标题、作者、年份、引用次数）
- `citations`: 总引用次数
- `h_index`: h-index
- `i10_index`: i10-index
- `co_authors`: 合作者列表（JSON 字符串格式，包含姓名和链接）

**注意事项**：
- `publications` 和 `co_authors` 字段为 JSON 字符串，需要解析后才能使用
- 著作列表限制为前 100 篇，合作者列表限制为前 50 个
- 支持断点续传，重新运行会跳过已处理的 URL
- 提取合作者时需要访问合作者页面，可能需要额外时间

---

### 4. `filter_citations.py` - 引用次数筛选工具

**功能**：根据引用次数筛选 CSV 文件，只保留引用次数大于指定阈值的记录。

**配置参数**（在文件中修改）：
```python
input_file = 'datp_raw_data.csv'           # 输入文件
output_file = 'dapt_raw_data_l50.csv'     # 输出文件
citation_threshold = 50                    # 引用次数阈值（修改 df[df['Citations'] > 50] 中的数字）
```

**使用方法**：
```bash
python filter_citations.py
```

**输入文件要求**：
- 必须包含 `Citations` 列
- CSV 格式

**输出文件**：筛选后的 CSV 文件

**注意事项**：
- 筛选条件为 `Citations > threshold`（大于阈值）
- 确保 `Citations` 列为数值类型

---

### 5. `filter_chinese_authors.py` - 中文作者筛选工具

**功能**：从 CSV 文件中筛选出第一作者为中文姓名的记录。

**配置参数**（在文件中修改）：
```python
chinese_names_file = '/path/to/chinesename_firstauthor.txt'  # 中文姓名列表（JSON 格式）
input_csv = '/path/to/input.csv'                             # 输入 CSV 文件
output_csv = '/path/to/output.csv'                           # 输出 CSV 文件
```

**使用方法**：
```bash
python filter_chinese_authors.py
```

**输入文件要求**：
- 输入 CSV 必须包含 `Authors_Raw` 列（如果没有 `first_author` 列，会自动从 `Authors_Raw` 提取第一作者）
- 中文姓名列表文件为 JSON 格式，包含中文姓名数组

**输出文件**：筛选后的 CSV 文件，只包含第一作者在中文姓名列表中的记录

**注意事项**：
- 如果没有 `first_author` 列，会自动从 `Authors_Raw` 列的第一个作者提取
- 中文姓名列表应为 JSON 格式的字符串数组

---

## 🔄 典型工作流程

### 流程 1：完整爬取流程

1. **爬取论文列表**：
   ```bash
   python 00gs_citation_crawler.py
   ```
   配置关键词和年份，生成包含论文信息的 CSV 文件

2. **筛选高引用论文**（可选）：
   ```bash
   python filter_citations.py
   ```
   修改文件中的阈值，筛选出高引用论文

3. **提取作者主页 URL**：
   ```bash
   python gs_homepage_url.py
   ```
   修改配置中的输入文件路径，提取所有作者的主页 URL

4. **筛选中文作者**（可选）：
   ```bash
   python filter_chinese_authors.py
   ```
   筛选出中文作者的数据

5. **爬取作者详细信息**：
   ```bash
   python gs_homepage_detail.py
   ```
   修改配置中的输入文件路径，爬取每个作者的详细信息

### 流程 2：快速筛选流程

1. 使用 `filter_citations.py` 筛选高引用论文
2. 使用 `filter_chinese_authors.py` 筛选中文作者

---

## 📦 依赖安装

```bash
pip install selenium pandas beautifulsoup4
```

**依赖说明**：
- `selenium`: 浏览器自动化工具（用于爬取 Google Scholar）
- `pandas`: 数据处理库（用于读取和写入 CSV）
- `beautifulsoup4`: HTML 解析库（部分脚本可能需要）

**额外要求**：
- **Chrome 浏览器**：必须安装 Chrome 浏览器
- **ChromeDriver**：必须安装与 Chrome 版本匹配的 ChromeDriver
  - 下载地址：https://chromedriver.chromium.org/
  - 或使用 `brew install chromedriver`（macOS）
  - 确保 ChromeDriver 在系统 PATH 中，或在代码中指定完整路径

---

## ⚠️ 重要注意事项

### 1. ChromeDriver 配置

所有使用 Selenium 的脚本都需要配置 ChromeDriver：

- **方法 1**：将 ChromeDriver 放在系统 PATH 中
- **方法 2**：在代码中指定完整路径（如 `CHROMEDRIVER_PATH = '/opt/homebrew/bin/chromedriver'`）

确保 ChromeDriver 版本与 Chrome 浏览器版本匹配。

### 2. 验证码处理

Google Scholar 可能会显示验证码（CAPTCHA）：

- 建议将 `HEADLESS_MODE` 设为 `False`，以便手动完成验证
- 脚本会自动检测验证码并等待用户完成
- 如果遇到频繁的验证码，建议：
  - 增加请求间隔时间
  - 使用代理 IP
  - 降低爬取速度

### 3. 断点续传

以下脚本支持断点续传（程序中断后重新运行会跳过已处理的数据）：
- `00gs_citation_crawler.py`
- `gs_homepage_url.py`
- `gs_homepage_detail.py`

### 4. 数据格式

- **CSV 文件**：使用 UTF-8 编码（带 BOM 的 UTF-8-sig）
- **JSON 字段**：`publications` 和 `co_authors` 字段为 JSON 字符串，需要使用 `json.loads()` 解析

### 5. 文件路径配置

所有脚本都需要在代码中配置输入/输出文件路径，请根据实际情况修改：
- 输入文件路径
- 输出文件路径
- ChromeDriver 路径

---

## 📝 数据格式说明

### 论文数据格式（`00gs_citation_crawler.py` 输出）

```csv
Title,Authors_Raw,Citations,Link,Snippet
"论文标题","作者1, 作者2 - 期刊, 2024",123,"https://...","摘要内容..."
```

### 作者主页 URL 格式（`gs_homepage_url.py` 输出）

```csv
paper_title,author_name,homepage_url
"论文标题","作者姓名","https://scholar.google.com/citations?user=..."
```

### 作者详情格式（`gs_homepage_detail.py` 输出）

```csv
homepage_url,name,affiliation,verified_email,homepage_link,research_interests,publications,citations,h_index,i10_index,co_authors
"https://...","姓名","机构","email@example.com","https://...","领域1; 领域2","[{\"title\":\"...\",\"year\":\"2024\"}]","1000","50","30","[{\"name\":\"合作者\",\"link\":\"...\"}]"
```

**JSON 字段解析示例**：

```python
import pandas as pd
import json

df = pd.read_csv('gs_homepage_detail.csv')

# 解析 publications 字段
for idx, row in df.iterrows():
    if pd.notna(row['publications']):
        publications = json.loads(row['publications'])
        print(f"作者 {row['name']} 有 {len(publications)} 篇著作")
        
# 解析 co_authors 字段
for idx, row in df.iterrows():
    if pd.notna(row['co_authors']):
        co_authors = json.loads(row['co_authors'])
        print(f"作者 {row['name']} 有 {len(co_authors)} 个合作者")
```

---

## 🐛 常见问题

### 1. ChromeDriver 版本不匹配

**错误信息**：`SessionNotCreatedException` 或 `This version of ChromeDriver only supports Chrome version XX`

**解决方法**：
- 检查 Chrome 浏览器版本：`chrome://version/`
- 下载对应版本的 ChromeDriver
- 或使用 `webdriver-manager` 自动管理驱动版本

### 2. 无法找到元素

**错误信息**：`NoSuchElementException` 或 `TimeoutException`

**可能原因**：
- Google Scholar 页面结构变化
- 页面加载过慢
- 遇到验证码

**解决方法**：
- 增加等待时间
- 检查页面是否正常加载
- 使用可见模式观察浏览器行为

### 3. 验证码频繁出现

**解决方法**：
- 降低爬取速度（增加 `time.sleep()` 时间）
- 使用代理 IP 轮换
- 使用可见模式手动处理验证码
- 考虑使用 API 替代爬虫（如果有官方 API）

### 4. 数据重复

**解决方法**：
- 脚本已内置去重功能（基于标题+作者或 URL）
- 如果仍有重复，可以手动使用 pandas 去重：
  ```python
  df = df.drop_duplicates(subset=['Title', 'Authors_Raw'])
  ```

### 5. 内存占用过高

**解决方法**：
- 脚本已实现边爬取边写入，不会将所有数据加载到内存
- 如果处理大量数据，可以考虑分批处理

---

## 📄 许可证

本工具集仅供学习和研究使用。请遵守 Google Scholar 的使用条款和 robots.txt 规定。

---

## 🔗 相关资源

- [Selenium 文档](https://www.selenium.dev/documentation/)
- [ChromeDriver 下载](https://chromedriver.chromium.org/)
- [Pandas 文档](https://pandas.pydata.org/docs/)

