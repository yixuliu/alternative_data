import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import urllib.parse
import time
import os

def get_all_authors_gs_homepages(paper_title, driver):
    """
    通过Selenium自动化浏览器，获取该论文下所有有主页的作者及其Google Scholar主页URL。
    返回格式: [{'author_name': '...', 'homepage_url': '...'}, ...]
    """
    try:
        # --- 步骤1: 构造搜索URL并访问 ---
        # 只搜索论文标题
        search_query = f'"{paper_title}"'
        encoded_query = urllib.parse.quote_plus(search_query)
        search_url = f"https://scholar.google.com/scholar?q={encoded_query}&hl=en"
        
        print(f"  -> 正在访问: {search_url}")
        driver.get(search_url)
        
        # 等待页面加载
        time.sleep(2)
        
        # --- 步骤1.5: 检查是否有验证码或重定向 ---
        current_url = driver.current_url
        page_source = driver.page_source.lower()
        
        # 检查是否被要求验证
        if 'sorry' in page_source or 'captcha' in page_source or 'verify' in page_source:
            print("  -> [警告] 可能遇到验证码或访问限制，尝试等待...")
            time.sleep(5)
            # 重新获取页面
            driver.get(search_url)
            time.sleep(3)
        
        # --- 步骤2: 等待搜索结果加载并找到论文条目 ---
        # 使用更长的等待时间和更灵活的CSS选择器
        wait = WebDriverWait(driver, 15)
        
        # 尝试多种CSS选择器来找到搜索结果
        paper_entry = None
        selectors = [
            "div.gs_r",  # 通用搜索结果
            "div.gs_r.gs_or",  # 带引用的结果
            "div.gs_ri",  # 搜索结果项
            "div[class*='gs_r']",  # 包含gs_r的div
        ]
        
        for selector in selectors:
            try:
                paper_entry = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                print(f"  -> [成功] 使用选择器 '{selector}' 找到搜索结果")
                break
            except TimeoutException:
                continue
        
        if paper_entry is None:
            # 如果还是找不到，尝试查找所有可能的论文条目
            try:
                all_results = driver.find_elements(By.CSS_SELECTOR, "div.gs_r, div.gs_ri, div[data-cid]")
                if all_results:
                    paper_entry = all_results[0]
                    print(f"  -> [成功] 找到 {len(all_results)} 个搜索结果，使用第一个")
                else:
                    # 保存页面源代码用于调试
                    debug_filename = f'/tmp/gs_debug_{paper_title[:20].replace("/", "_")}.html'
                    with open(debug_filename, 'w', encoding='utf-8') as f:
                        f.write(driver.page_source)
                    print(f"  -> [失败] 未找到任何搜索结果")
                    print(f"  -> [调试] 页面标题: {driver.title}")
                    print(f"  -> [调试] 当前URL: {driver.current_url}")
                    print(f"  -> [调试] 页面源代码已保存到 {debug_filename}")
                    return []
            except Exception as e:
                print(f"  -> [失败] 搜索时出错: {e}")
                return []
        
        # 获取所有搜索结果，找到最匹配的论文
        all_results = driver.find_elements(By.CSS_SELECTOR, "div.gs_r, div.gs_ri, div[data-cid]")
        
        # 存储所有找到的作者主页
        authors_with_homepages = []
        found_paper = False
        
        # 检查前3个结果，找到匹配的论文并提取所有作者链接
        for result in all_results[:3]:  # 只检查前3个结果
            try:
                # 在 gs_a (作者信息) 中查找所有作者链接
                authors_containers = result.find_elements(By.CSS_SELECTOR, "div.gs_a")
                if not authors_containers:
                    authors_containers = result.find_elements(By.CSS_SELECTOR, ".gs_a")
                
                for authors_container in authors_containers:
                    links = authors_container.find_elements(By.TAG_NAME, "a")
                    for link in links:
                        href = link.get_attribute('href')
                        link_text = link.text.strip()
                        
                        # 检查链接是否是作者主页链接（包含 'citations?user=' 或类似格式）
                        if href and ('citations?user=' in href or '/citations?' in href or '/citations' in href):
                            # 确保URL是完整的
                            if not href.startswith('http'):
                                href = 'https://scholar.google.com' + href
                            
                            # 获取作者名（从链接文本，如果没有则尝试从href解析）
                            author_name = link_text if link_text else "Unknown Author"
                            
                            # 检查是否已经添加过这个作者（避免重复）
                            if not any(a['homepage_url'] == href for a in authors_with_homepages):
                                authors_with_homepages.append({
                                    'author_name': author_name,
                                    'homepage_url': href
                                })
                                found_paper = True
                                print(f"  -> [找到] 作者: {author_name} - {href}")
                    
            except Exception as e:
                continue
        
        if authors_with_homepages:
            print(f"  -> [成功] 找到 {len(authors_with_homepages)} 个有主页的作者")
            return authors_with_homepages
        else:
            if found_paper:
                print("  -> [信息] 找到了论文，但该作者没有Google Scholar主页")
            else:
                print("  -> [失败] 在搜索结果中未找到作者链接")
                print(f"  -> [调试] 已检查前 {min(3, len(all_results))} 个结果")
            return []

    except TimeoutException:
        print("  -> [失败] 页面加载超时")
        print(f"  -> [调试] 当前URL: {driver.current_url}")
        return []
    except Exception as e:
        print(f"  -> [错误] 发生未知错误: {e}")
        import traceback
        traceback.print_exc()
        return []

def main():
    """
    主函数，读取CSV并自动化浏览器获取所有作者的主页URL。
    """
    # --- 配置 ---
    INPUT_CSV = '/Users/yvesliu/Desktop/test/gaorong/dapt_raw_data_l50.csv'
    OUTPUT_CSV = '/Users/yvesliu/Desktop/test/gaorong/dapt_all_authors_homepages_all.csv'
    DRIVER_PATH = None  # 如果chromedriver在系统PATH中，可以为None；否则指定路径，如 './chromedriver'
    HEADLESS_MODE = False  # 设为 False 可以看到浏览器窗口，更容易调试和避免被检测

    # --- 检查输入文件是否存在 ---
    if not os.path.exists(INPUT_CSV):
        print(f"错误：找不到输入文件 '{INPUT_CSV}'。")
        return
    
    print(f"📖 正在读取输入文件: {INPUT_CSV}...")
    
    try:
        # 先读取CSV文件（这样用户可以看到进度）
        df = pd.read_csv(INPUT_CSV)
        print(f"  ✅ 成功读取 {len(df)} 行数据")
        
        # 检查必要的列是否存在（只需要标题列）
        title_col = None
        
        # 查找标题列（匹配 'title'，不区分大小写，支持 'Title'）
        for col in df.columns:
            if col.lower() == 'title':
                title_col = col
                break
        
        if title_col is None:
            print(f"错误：输入文件 '{INPUT_CSV}' 中缺少必要的列。")
            print(f"找到的列: {', '.join(df.columns)}")
            print("请确保文件中包含：")
            print("  - 标题列：'Title' 或 'title' (不区分大小写)")
            return
        
        print(f"  ✓ 已识别列名:")
        print(f"     - 标题列: '{title_col}'")
        print(f"  ✓ 共 {len(df)} 条记录需要处理")
        print(f"  ℹ️  将获取每篇论文下所有有主页的作者\n")
        
    except Exception as e:
        print(f"❌ 读取CSV文件失败: {e}")
        return
    
    # 现在启动浏览器（这个过程可能需要一些时间）
    print("🚀 正在启动Chrome浏览器...")
    print("   （首次启动可能需要30-60秒，请耐心等待）")
    
    # 设置Selenium WebDriver
    options = webdriver.ChromeOptions()
    
    if HEADLESS_MODE:
        options.add_argument('--headless')  # 无头模式，不显示浏览器窗口
        print("   ⚠️  使用无头模式，可能更容易被检测")
    else:
        print("   ✅ 使用可见模式（可以看到浏览器窗口）")
        # 确保浏览器窗口显示在前面
        options.add_argument('--start-maximized')  # 最大化窗口
        options.add_experimental_option("detach", True)  # 保持浏览器打开
    
    # 基本选项
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-blink-features=AutomationControlled')  # 隐藏自动化标识
    options.add_argument('--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    
    # 添加更多真实浏览器的特征
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    # 初始化Chrome驱动（直接使用系统PATH中的ChromeDriver）
    driver = None
    try:
        print("   ✅ 使用系统PATH中的ChromeDriver...")
        
        if DRIVER_PATH and os.path.exists(DRIVER_PATH):
            print(f"   📍 使用指定路径: {DRIVER_PATH}")
            # Selenium 4语法：使用Service类
            service = Service(DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)
        else:
            print("   📍 使用系统PATH中的ChromeDriver")
            # 直接使用PATH中的ChromeDriver
            driver = webdriver.Chrome(options=options)
        
        # 验证浏览器是否正常启动
        if driver is None:
            raise Exception("浏览器驱动初始化失败，driver为None")
        
        # 最大化窗口（确保可见）
        if not HEADLESS_MODE:
            try:
                driver.maximize_window()
                print("   ✅ 浏览器窗口已最大化")
            except:
                pass
        
        # 打开一个测试页面，验证浏览器是否正常工作
        print("   🔍 测试浏览器连接...")
        driver.get("about:blank")
        print(f"   ✅ 浏览器已连接，当前URL: {driver.current_url}")
        print(f"   ✅ 浏览器标题: {driver.title}")
        
        # 执行JavaScript隐藏自动化标识
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
                window.navigator.chrome = {
                    runtime: {}
                };
                Object.defineProperty(navigator, 'languages', {
                    get: () => ['en-US', 'en']
                });
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1, 2, 3, 4, 5]
                });
            '''
        })
        print("  ✅ 已配置反检测措施")
        
    except Exception as e:
        print(f"❌ 错误：无法启动Chrome浏览器。")
        print(f"   请检查：")
        print(f"   1. 是否已安装Chrome浏览器")
        print(f"   2. ChromeDriver是否在PATH中或路径是否正确")
        print(f"   3. ChromeDriver版本是否与Chrome浏览器版本匹配")
        print(f"   错误详情: {e}")
        import traceback
        traceback.print_exc()
        if driver:
            try:
                driver.quit()
            except:
                pass
        return

    print("  ✅ 浏览器已启动，窗口应该已经显示，开始处理...\n")
    
    # --- 检查输出文件是否存在，支持断点续传 ---
    processed_papers = set()  # 存储已处理过的论文标题（标准化后的）
    file_exists = os.path.exists(OUTPUT_CSV)
    need_header = not file_exists  # 如果文件不存在才需要header
    
    if file_exists:
        try:
            # 尝试多种方式读取CSV文件，处理格式错误
            existing_df = None
            try:
                # 方式1：正常读取
                existing_df = pd.read_csv(OUTPUT_CSV)
            except Exception as e1:
                print(f"  ⚠️  正常读取失败，尝试跳过错误行: {e1}")
                try:
                    # 方式2：跳过格式错误的行
                    existing_df = pd.read_csv(OUTPUT_CSV, on_bad_lines='skip', engine='python')
                except Exception as e2:
                    print(f"  ⚠️  跳过错误行也失败，尝试手动解析: {e2}")
                    # 方式3：手动读取文件，过滤掉格式错误和重复header
                    import csv
                    rows = []
                    header_row = None
                    with open(OUTPUT_CSV, 'r', encoding='utf-8-sig') as f:
                        reader = csv.reader(f)
                        for i, row in enumerate(reader):
                            if i == 0:
                                header_row = row
                                continue
                            # 跳过重复的header行
                            if row and row[0] == 'paper_title':
                                continue
                            # 只保留格式正确的行（至少有3列）
                            if len(row) >= 3:
                                rows.append(row)
                    if header_row and rows:
                        existing_df = pd.DataFrame(rows, columns=header_row)
            
            if existing_df is not None and len(existing_df) > 0:
                print(f"  📋 检测到已有输出文件: {OUTPUT_CSV}")
                print(f"  📊 文件中有 {len(existing_df)} 行有效数据")
                
                if 'paper_title' in existing_df.columns:
                    # 获取所有已处理的论文标题（标准化：去除首尾空格，转字符串）
                    processed_titles = existing_df['paper_title'].dropna().astype(str).str.strip()
                    # 过滤掉可能的header行（标题恰好是"paper_title"的情况）
                    processed_titles = processed_titles[processed_titles != 'paper_title']
                    processed_papers = set(processed_titles.unique())
                    need_header = False
                    print(f"  ✅ 成功读取已处理论文列表，共 {len(processed_papers)} 篇不同的论文")
                    
                    # 显示前几个已处理的论文（用于调试）
                    if len(processed_papers) > 0:
                        sample_titles = list(processed_papers)[:3]
                        print(f"  📝 示例已处理论文（前3篇）:")
                        for title in sample_titles:
                            print(f"     - {title[:60]}...")
                    print(f"  ➡️  将从断点继续处理（跳过已处理的论文）...\n")
                else:
                    print(f"  ⚠️  输出文件中没有 'paper_title' 列，将重新开始")
                    print(f"  📋 输出文件的列: {', '.join(existing_df.columns)}")
                    need_header = True
                    processed_papers = set()
            else:
                print(f"  ⚠️  文件中没有有效数据，将重新开始")
                need_header = True
                processed_papers = set()
        except Exception as e:
            print(f"  ⚠️  读取现有文件时出错: {e}")
            import traceback
            traceback.print_exc()
            print(f"  ➡️  将重新开始处理")
            need_header = True
            processed_papers = set()
    else:
        print(f"  📝 输出文件不存在，将创建新文件: {OUTPUT_CSV}\n")
    
    # 统计变量
    total_processed = 0
    success_count = 0
    skipped_count = 0
    
    # 预先统计需要处理的论文数量
    total_to_process = len(df)
    total_skipped = 0
    total_to_do = 0
    
    # 预扫描：统计有多少论文已处理，多少需要处理
    print("  🔍 正在扫描输入文件，统计需要处理的论文...")
    for index, row in df.iterrows():
        paper_title_raw = str(row[title_col]) if pd.notna(row[title_col]) else ''
        paper_title = paper_title_raw.strip()
        if not paper_title:
            continue
        if paper_title in processed_papers:
            total_skipped += 1
        else:
            total_to_do += 1
    
    print(f"  📊 统计结果:")
    print(f"     - 总论文数: {total_to_process}")
    print(f"     - 已处理（将跳过）: {total_skipped} 篇")
    print(f"     - 待处理: {total_to_do} 篇")
    print(f"  ➡️  开始处理...\n")
    
    try:
        for index, row in df.iterrows():
            paper_title_raw = str(row[title_col]) if pd.notna(row[title_col]) else ''
            paper_title = paper_title_raw.strip()  # 标准化：去除首尾空格
            
            # 跳过空值行
            if not paper_title:
                print(f"({index+1}/{len(df)}) 跳过空标题行")
                continue
            
            # 检查是否已经处理过这篇论文（使用标准化后的标题）
            if paper_title in processed_papers:
                skipped_count += 1
                print(f"({index+1}/{len(df)}) ⏭️  跳过已处理 [{skipped_count}/{total_skipped}]: {paper_title[:60]}...")
                continue
            
            print(f"({index+1}/{len(df)}) 处理论文: {paper_title[:60]}...")
            
            # 获取该论文下所有有主页的作者
            authors_homepages = get_all_authors_gs_homepages(paper_title, driver)
            
            # 准备要写入的数据（每行一个作者）
            rows_to_write = []
            if authors_homepages:
                for author_info in authors_homepages:
                    rows_to_write.append({
                        'paper_title': paper_title,
                        'author_name': author_info['author_name'],
                        'homepage_url': author_info['homepage_url']
                    })
                    success_count += 1
            else:
                # 即使没找到作者主页，也记录论文标题（便于后续检查）
                rows_to_write.append({
                    'paper_title': paper_title,
                    'author_name': None,
                    'homepage_url': None
                })
            
            # 立即写入CSV文件（追加模式）
            if rows_to_write:
                output_df = pd.DataFrame(rows_to_write)
                # 使用追加模式，只在第一次写入时包含header
                output_df.to_csv(OUTPUT_CSV, mode='a', index=False, 
                                encoding='utf-8-sig', header=need_header)
                need_header = False  # 后续追加都不需要header
                
                print(f"  💾 已保存 {len(rows_to_write)} 条记录到文件")
            
            # 标记为已处理（使用标准化后的标题）
            processed_papers.add(paper_title)
            total_processed += 1
            
            # 添加延时，模拟人类行为，避免被检测
            time.sleep(3)

        # 处理完成
        print("\n" + "=" * 50)
        print(f"✅ 处理完成！")
        print(f"📊 跳过已处理论文: {skipped_count} 篇")
        print(f"📊 本次新处理论文: {total_processed} 篇")
        print(f"📊 累计已处理论文: {len(processed_papers)} 篇")
        print(f"✅ 本次成功获取 {success_count} 个作者主页URL")
        
        # 统计累计成功数
        if file_exists:
            try:
                final_df = pd.read_csv(OUTPUT_CSV)
                total_success = final_df['homepage_url'].notna().sum()
                print(f"✅ 累计成功获取 {total_success} 个作者主页URL")
            except:
                pass
        
        print(f"💾 结果已保存到: {OUTPUT_CSV}")
        print("=" * 50)

    except Exception as e:
        print(f"处理文件时发生错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # 确保浏览器被关闭
        print("\n正在关闭浏览器...")
        driver.quit()

if __name__ == '__main__':
    main()
