import pandas as pd
import json

# 读取中文作者名单（JSON格式）
with open('/Users/yvesliu/Desktop/test/gaorong/py file/chinesename_firstauthor.txt', 'r', encoding='utf-8') as f:
    chinese_names = set(json.load(f))

# 读取CSV文件
df = pd.read_csv('/Users/yvesliu/Desktop/test/gaorong/raw_data20.csv')

# 如果没有first_author列，从Authors_Raw提取
if 'first_author' not in df.columns:
    df['first_author'] = df['Authors_Raw'].str.split(',').str[0].str.strip()

# 筛选匹配的行
filtered_df = df[df['first_author'].isin(chinese_names)]

# 保存结果
filtered_df.to_csv('../chinese_author_scholardata.csv', index=False)
print(f"已筛选出 {len(filtered_df)} 行数据")

