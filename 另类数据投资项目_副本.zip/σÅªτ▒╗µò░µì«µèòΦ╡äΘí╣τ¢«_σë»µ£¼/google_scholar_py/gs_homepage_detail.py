#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google Scholar 主页详情爬虫
从包含Google Scholar主页URL的CSV文件中读取URL，爬取作者详细信息并保存到 gs_homepage_detail.csv
支持断点续传，边爬边写入
"""

import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
import os
import json
import re


def extract_author_details(homepage_url, driver):
    """
    从Google Scholar主页URL提取作者详细信息
    
    返回格式:
    {
        'name': '...',
        'affiliation': '...',
        'verified_email': '...',
        'homepage_link': '...',
        'research_interests': '...',
        'publications': '...',  # JSON字符串格式
        'citations': '...',
        'h_index': '...',
        'i10_index': '...',
        'co_authors': '...',  # JSON字符串格式
    }
    """
    details = {
        'homepage_url': homepage_url,
        'name': '',
        'affiliation': '',
        'verified_email': '',
        'homepage_link': '',
        'research_interests': '',
        'publications': '',
        'citations': '',
        'h_index': '',
        'i10_index': '',
        'co_authors': ''
    }
    
    try:
        print(f"  -> 正在访问主页: {homepage_url}")
        driver.get(homepage_url)
        time.sleep(3)  # 等待页面加载
        
        # 检查是否有验证码或访问限制
        page_source = driver.page_source.lower()
        if 'sorry' in page_source or 'captcha' in page_source or 'verify' in page_source:
            print("  -> [警告] 可能遇到验证码或访问限制")
            time.sleep(5)
            driver.get(homepage_url)
            time.sleep(3)
        
        wait = WebDriverWait(driver, 10)
        
        # --- 1. 提取姓名 ---
        try:
            # Google Scholar主页的姓名字段通常在 id="gsc_prf_in" 中
            name_element = driver.find_element(By.ID, "gsc_prf_in")
            details['name'] = name_element.text.strip()
            print(f"  -> 姓名: {details['name']}")
        except NoSuchElementException:
            # 备用方法：尝试其他选择器
            try:
                name_element = driver.find_element(By.CSS_SELECTOR, "div#gsc_prf_in, h2.gsc_authors_name")
                details['name'] = name_element.text.strip()
            except:
                print("  -> [警告] 无法提取姓名")
        
        # --- 2. 提取任职单位/机构 ---
        try:
            # 任职单位通常在 id="gsc_prf_i" 中
            affiliation_element = driver.find_element(By.ID, "gsc_prf_i")
            details['affiliation'] = affiliation_element.text.strip()
            print(f"  -> 任职单位: {details['affiliation']}")
        except NoSuchElementException:
            try:
                affiliation_element = driver.find_element(By.CSS_SELECTOR, "div#gsc_prf_i, a.gsc_authors_aff")
                details['affiliation'] = affiliation_element.text.strip()
            except:
                print("  -> [警告] 无法提取任职单位")
        
        # --- 3. 提取验证邮箱 ---
        try:
            # 邮箱可能在 id="gsc_prf_ivh" 或相关区域
            email_elements = driver.find_elements(By.CSS_SELECTOR, "a[href^='mailto:'], div#gsc_prf_ivh a")
            if email_elements:
                email_link = email_elements[0].get_attribute('href')
                if email_link and 'mailto:' in email_link:
                    details['verified_email'] = email_link.replace('mailto:', '').strip()
                    print(f"  -> 验证邮箱: {details['verified_email']}")
        except:
            try:
                # 尝试在主页描述中查找邮箱
                profile_text = driver.find_element(By.ID, "gsc_prf_in").get_attribute('textContent')
                email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
                emails = re.findall(email_pattern, profile_text)
                if emails:
                    details['verified_email'] = emails[0]
            except:
                print("  -> [警告] 无法提取验证邮箱")
        
        # --- 4. 提取个人主页链接 ---
        try:
            # 查找外部主页链接
            homepage_links = driver.find_elements(By.CSS_SELECTOR, "div#gsc_prf_ivh a, a.gsc_prf_ila")
            for link in homepage_links:
                href = link.get_attribute('href')
                text = link.text.strip().lower()
                # 排除Google Scholar相关链接和邮箱链接
                if href and 'scholar.google.com' not in href and 'mailto:' not in href:
                    if 'homepage' in text or 'website' in text or 'www' in text or 'http' in href:
                        details['homepage_link'] = href
                        print(f"  -> 个人主页链接: {details['homepage_link']}")
                        break
        except:
            print("  -> [警告] 无法提取个人主页链接")
        
        # --- 5. 提取研究领域/兴趣 ---
        try:
            # 研究领域可能在 id="gsc_prf_int" 中
            interests_element = driver.find_element(By.ID, "gsc_prf_int")
            interests_list = interests_element.find_elements(By.CSS_SELECTOR, "a.gsc_prf_inta")
            if interests_list:
                interests = [item.text.strip() for item in interests_list]
                details['research_interests'] = '; '.join(interests)
                print(f"  -> 研究领域: {details['research_interests']}")
        except NoSuchElementException:
            try:
                interests_element = driver.find_element(By.CSS_SELECTOR, "div#gsc_prf_int")
                details['research_interests'] = interests_element.text.strip()
            except:
                print("  -> [警告] 无法提取研究领域")
        
        # --- 6. 提取引用指标 ---
        try:
            # 尝试从统计表格中提取
            stats_table = driver.find_element(By.ID, "gsc_rsb_st")
            rows = stats_table.find_elements(By.XPATH, ".//tbody/tr")
            
            # 引用次数（通常是第一行）
            if len(rows) > 0:
                citations_cell = rows[0].find_element(By.XPATH, ".//td[2]")
                details['citations'] = citations_cell.text.strip()
                print(f"  -> 引用次数: {details['citations']}")
            
            # h-index（通常是第二行）
            if len(rows) > 1:
                h_index_cell = rows[1].find_element(By.XPATH, ".//td[2]")
                details['h_index'] = h_index_cell.text.strip()
                print(f"  -> h-index: {details['h_index']}")
            
            # i10-index（通常是第三行）
            if len(rows) > 2:
                i10_cell = rows[2].find_element(By.XPATH, ".//td[2]")
                details['i10_index'] = i10_cell.text.strip()
                print(f"  -> i10-index: {details['i10_index']}")
                
        except:
            # 备用方法：尝试其他选择器
            try:
                # 引用次数
                citations_element = driver.find_element(By.CSS_SELECTOR, "td.gsc_rsb_std")
                details['citations'] = citations_element.text.strip()
                print(f"  -> 引用次数: {details['citations']}")
            except:
                print("  -> [警告] 无法提取引用次数")
            
            try:
                # h-index - 可能在页面其他地方显示
                h_index_elements = driver.find_elements(By.CSS_SELECTOR, "td.gsc_rsb_std")
                if len(h_index_elements) > 1:
                    details['h_index'] = h_index_elements[1].text.strip()
                    print(f"  -> h-index: {details['h_index']}")
            except:
                print("  -> [警告] 无法提取h-index")
            
            try:
                # i10-index
                i10_elements = driver.find_elements(By.CSS_SELECTOR, "td.gsc_rsb_std")
                if len(i10_elements) > 2:
                    details['i10_index'] = i10_elements[2].text.strip()
                    print(f"  -> i10-index: {details['i10_index']}")
            except:
                print("  -> [警告] 无法提取i10-index")
        
        # --- 7. 提取著作列表 ---
        try:
            publications = []
            # 查找所有著作项（在表格中）
            pub_elements = driver.find_elements(By.CSS_SELECTOR, "tr.gsc_a_tr")
            
            # 如果没找到，尝试滚动加载更多
            if len(pub_elements) == 0:
                # 尝试点击"显示更多"按钮
                try:
                    show_more = driver.find_element(By.CSS_SELECTOR, "button#gsc_bpf_more")
                    if show_more.is_displayed():
                        show_more.click()
                        time.sleep(2)
                        pub_elements = driver.find_elements(By.CSS_SELECTOR, "tr.gsc_a_tr")
                except:
                    pass
            
            for pub in pub_elements[:100]:  # 限制前100篇，避免数据过多
                try:
                    # 提取标题
                    title = ''
                    try:
                        title_elem = pub.find_element(By.CSS_SELECTOR, "a.gsc_a_at")
                        title = title_elem.text.strip()
                    except:
                        try:
                            title_elem = pub.find_element(By.CSS_SELECTOR, "td.gsc_a_t a")
                            title = title_elem.text.strip()
                        except:
                            continue
                    
                    # 提取作者、发表信息等
                    authors_info = ''
                    try:
                        authors_elem = pub.find_element(By.CSS_SELECTOR, "div.gs_gray")
                        authors_info = authors_elem.text.strip()
                    except:
                        try:
                            authors_elem = pub.find_element(By.CSS_SELECTOR, "div.gsc_a_c, div.gsc_a_t")
                            authors_info = authors_elem.text.strip()
                        except:
                            pass
                    
                    # 提取年份
                    year = ''
                    try:
                        year_elem = pub.find_element(By.CSS_SELECTOR, "span.gsc_a_y")
                        year = year_elem.text.strip()
                    except:
                        try:
                            year_elem = pub.find_element(By.CSS_SELECTOR, "td.gsc_a_y span")
                            year = year_elem.text.strip()
                        except:
                            pass
                    
                    # 提取引用次数
                    citations_count = ''
                    try:
                        citations_elem = pub.find_element(By.CSS_SELECTOR, "a.gsc_a_c")
                        citations_count = citations_elem.text.strip()
                    except:
                        try:
                            citations_elem = pub.find_element(By.CSS_SELECTOR, "td.gsc_a_c a")
                            citations_count = citations_elem.text.strip()
                        except:
                            pass
                    
                    if title:  # 只要有标题就保存
                        publications.append({
                            'title': title,
                            'authors': authors_info,
                            'year': year,
                            'citations': citations_count
                        })
                except Exception as e:
                    continue
            
            if publications:
                details['publications'] = json.dumps(publications, ensure_ascii=False)
                print(f"  -> 提取到 {len(publications)} 篇著作")
            else:
                print("  -> [警告] 未找到著作列表")
        except Exception as e:
            print(f"  -> [警告] 提取著作列表时出错: {e}")
        
        # --- 8. 提取合作者列表 ---
        try:
            print("  -> 开始提取合作者列表...")
            # 需要先回到主页，然后点击"合作者"标签页
            driver.get(homepage_url)
            time.sleep(2)
            
            # 查找合作者链接（可能在页面顶部的导航栏）
            coauthors_link = None
            try:
                # 尝试多种方式查找合作者链接
                link_selectors = [
                    "a.gsc_lc_m",
                    "a[href*='coauthors']",
                    "a[href*='list_colleagues']",
                    "//a[contains(text(), 'Co-authors')]",
                    "//a[contains(text(), '合作者')]"
                ]
                
                for selector in link_selectors:
                    try:
                        if selector.startswith("//"):
                            coauthors_link = driver.find_element(By.XPATH, selector)
                        else:
                            coauthors_link = driver.find_element(By.CSS_SELECTOR, selector)
                        if coauthors_link:
                            print(f"  -> 找到合作者链接，正在点击...")
                            coauthors_link.click()
                            time.sleep(4)  # 增加等待时间
                            break
                    except:
                        continue
                
                if not coauthors_link:
                    raise Exception("未找到合作者链接")
                    
            except:
                # 备用方法：直接在URL中添加参数
                print("  -> 尝试通过URL直接访问合作者页面...")
                try:
                    # 构建合作者页面URL
                    if 'list_colleagues' not in homepage_url:
                        if '?' in homepage_url:
                            coauthors_url = homepage_url + '&view_op=list_colleagues'
                        else:
                            coauthors_url = homepage_url + '?view_op=list_colleagues'
                    else:
                        coauthors_url = homepage_url.replace('&view_op=list_works', '&view_op=list_colleagues').replace('view_op=list_works', 'view_op=list_colleagues')
                    
                    print(f"  -> 访问URL: {coauthors_url}")
                    driver.get(coauthors_url)
                    time.sleep(4)  # 增加等待时间
                except Exception as e:
                    print(f"  -> [警告] 无法访问合作者页面: {e}")
            
            # 等待页面加载完成
            try:
                # 等待至少一个可能的合作者元素出现
                wait = WebDriverWait(driver, 10)
                wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "span.gsc_rsb_a_desc, a.gsc_rsb_aa, div.gsc_rsb_a, tr.gsc_rsb_a_tr, td.gsc_rsb_a")) > 0 or 
                           len(d.find_elements(By.XPATH, "//a[contains(@href, 'citations?user=')]")) > 0)
                print("  -> 页面已加载，开始提取合作者...")
            except:
                print("  -> [警告] 等待页面加载超时，继续尝试提取...")
                time.sleep(2)
            
            coauthors = []
            # 尝试多种选择器来查找合作者（按优先级）
            coauthor_selectors = [
                "a.gsc_rsb_aa",  # 链接元素
                "span.gsc_rsb_a_desc",  # 描述元素
                "tr.gsc_rsb_a_tr",  # 表格行
                "div.gsc_rsb_a",  # div容器
                "td.gsc_rsb_a",  # 表格单元格
                "//a[contains(@href, 'citations?user=')]",  # XPath查找包含用户ID的链接
            ]
            
            coauthor_elements = []
            for selector in coauthor_selectors:
                try:
                    if selector.startswith("//"):
                        elements = driver.find_elements(By.XPATH, selector)
                    else:
                        elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements:
                        print(f"  -> 使用选择器 '{selector}' 找到 {len(elements)} 个元素")
                        coauthor_elements = elements
                        break
                except Exception as e:
                    continue
            
            if not coauthor_elements:
                print("  -> [调试] 尝试查找所有可能的链接...")
                # 尝试更宽泛的搜索
                all_links = driver.find_elements(By.XPATH, "//a[contains(@href, 'citations?user=')]")
                if all_links:
                    print(f"  -> 找到 {len(all_links)} 个可能包含用户ID的链接")
                    coauthor_elements = all_links
            
            print(f"  -> 开始处理 {len(coauthor_elements)} 个合作者元素...")
            processed_names = set()  # 避免重复
            
            for elem in coauthor_elements[:50]:  # 限制前50个合作者
                try:
                    name = ''
                    link = ''
                    
                    # 尝试提取名称和链接
                    if elem.tag_name == 'a':
                        name = elem.text.strip()
                        link = elem.get_attribute('href') or ''
                        # 如果名称为空，尝试从其他属性获取
                        if not name:
                            name = elem.get_attribute('title') or ''
                    else:
                        name = elem.text.strip()
                        # 尝试在父元素或子元素中查找链接
                        try:
                            # 先尝试查找子元素中的链接
                            link_elem = elem.find_element(By.TAG_NAME, "a")
                            if link_elem:
                                link = link_elem.get_attribute('href') or ''
                                if not name:
                                    name = link_elem.text.strip()
                        except:
                            try:
                                # 尝试查找父元素中的链接
                                parent_link = elem.find_element(By.XPATH, "./ancestor::a[1]")
                                link = parent_link.get_attribute('href') or ''
                                if not name:
                                    name = parent_link.text.strip()
                            except:
                                # 尝试查找兄弟元素中的链接
                                try:
                                    sibling_link = elem.find_element(By.XPATH, "./following-sibling::a[1] | ./preceding-sibling::a[1]")
                                    link = sibling_link.get_attribute('href') or ''
                                    if not name:
                                        name = sibling_link.text.strip()
                                except:
                                    pass
                    
                    # 清理名称（移除多余的空白字符）
                    if name:
                        name = ' '.join(name.split())
                    
                    # 只有当名称不为空且不重复时才添加
                    if name and name not in processed_names and len(name) > 1:
                        # 过滤掉明显不是合作者的元素（比如"View all X co-authors"链接）
                        if 'view all' not in name.lower() and 'co-author' not in name.lower() and '合作者' not in name:
                            processed_names.add(name)
                            coauthors.append({
                                'name': name,
                                'link': link
                            })
                            if len(coauthors) <= 5:  # 只打印前5个用于调试
                                print(f"    - 合作者 {len(coauthors)}: {name}")
                except Exception as e:
                    continue
            
            if coauthors:
                details['co_authors'] = json.dumps(coauthors, ensure_ascii=False)
                print(f"  -> ✅ 成功提取到 {len(coauthors)} 个合作者")
            else:
                print("  -> [警告] 未找到合作者列表")
                # 调试信息：打印页面标题和URL
                print(f"    当前页面标题: {driver.title}")
                print(f"    当前页面URL: {driver.current_url}")
        except Exception as e:
            print(f"  -> [警告] 提取合作者列表时出错: {e}")
            import traceback
            traceback.print_exc()
        
        return details
        
    except Exception as e:
        print(f"  -> [错误] 处理主页时出错: {e}")
        import traceback
        traceback.print_exc()
        return details


def main():
    # --- 配置参数 ---
    INPUT_CSV = '/Users/yvesliu/Desktop/test/gaorong/gs_Chinese_authors_homepages_unique.csv'  # 输入文件：包含homepage_url列的CSV    INPUT_CSV = '/Users/yvesliu/Desktop/test/gaorong/gs_
    OUTPUT_CSV = '/Users/yvesliu/Desktop/test/gaorong/gs_homepage_detail.csv'  # 输出文件
    
    # ChromeDriver路径（如果需要指定）
    DRIVER_PATH = None  # 例如: '/usr/local/bin/chromedriver'，None则使用PATH中的
    
    # 是否使用无头模式
    HEADLESS_MODE = False  # 设为 False 可以看到浏览器窗口，更容易调试和避免被检测
    
    # --- 检查输入文件是否存在 ---
    if not os.path.exists(INPUT_CSV):
        print(f"❌ 错误：找不到输入文件 '{INPUT_CSV}'。")
        print(f"请确保输入文件包含 'homepage_url' 列（或类似的URL列名）")
        return
    
    print(f"📖 正在读取输入文件: {INPUT_CSV}...")
    
    try:
        # 读取CSV文件
        df = pd.read_csv(INPUT_CSV)
        print(f"  ✅ 成功读取 {len(df)} 行数据")
        
        # 查找URL列
        url_col = None
        for col in df.columns:
            if 'url' in col.lower() or 'homepage' in col.lower():
                url_col = col
                break
        
        if url_col is None:
            print(f"❌ 错误：输入文件 '{INPUT_CSV}' 中缺少URL列。")
            print(f"找到的列: {', '.join(df.columns)}")
            print("请确保文件中包含包含 'homepage_url' 或类似的URL列")
            return
        
        print(f"  ✓ 已识别URL列: '{url_col}'")
        
        # 过滤掉空URL
        df = df[df[url_col].notna() & (df[url_col].astype(str).str.strip() != '')]
        print(f"  ✓ 有效URL数量: {len(df)} 条\n")
        
    except Exception as e:
        print(f"❌ 读取CSV文件失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # --- 启动浏览器 ---
    print("🚀 正在启动Chrome浏览器...")
    print("   （首次启动可能需要30-60秒，请耐心等待）")
    
    options = webdriver.ChromeOptions()
    
    if HEADLESS_MODE:
        options.add_argument('--headless')
        print("   ⚠️  使用无头模式")
    else:
        print("   ✅ 使用可见模式")
        options.add_argument('--start-maximized')
        options.add_experimental_option("detach", True)
    
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument('--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    
    driver = None
    try:
        if DRIVER_PATH and os.path.exists(DRIVER_PATH):
            service = Service(DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)
        else:
            driver = webdriver.Chrome(options=options)
        
        if driver is None:
            raise Exception("浏览器驱动初始化失败")
        
        if not HEADLESS_MODE:
            try:
                driver.maximize_window()
            except:
                pass
        
        driver.get("about:blank")
        print("   ✅ 浏览器已连接")
        
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
                window.navigator.chrome = {
                    runtime: {}
                };
            '''
        })
        print("  ✅ 已配置反检测措施\n")
        
    except Exception as e:
        print(f"❌ 错误：无法启动Chrome浏览器。")
        print(f"   错误详情: {e}")
        import traceback
        traceback.print_exc()
        if driver:
            try:
                driver.quit()
            except:
                pass
        return
    
    # --- 检查输出文件，支持断点续传 ---
    processed_urls = set()
    file_exists = os.path.exists(OUTPUT_CSV)
    need_header = not file_exists
    
    if file_exists:
        try:
            existing_df = pd.read_csv(OUTPUT_CSV, on_bad_lines='skip', engine='python')
            if len(existing_df) > 0 and 'homepage_url' in existing_df.columns:
                processed_urls = set(existing_df['homepage_url'].dropna().astype(str).str.strip())
                processed_urls = processed_urls - {''}
                print(f"  📋 检测到已有输出文件: {OUTPUT_CSV}")
                print(f"  ✅ 已处理 {len(processed_urls)} 个URL，将从断点继续\n")
                need_header = False
            else:
                need_header = True
                processed_urls = set()
        except Exception as e:
            print(f"  ⚠️  读取现有文件时出错: {e}，将重新开始")
            need_header = True
            processed_urls = set()
    else:
        print(f"  📝 输出文件不存在，将创建新文件: {OUTPUT_CSV}\n")
    
    # --- 统计变量 ---
    total_processed = 0
    success_count = 0
    skipped_count = 0
    
    # --- 处理每个URL ---
    try:
        for index, row in df.iterrows():
            homepage_url_raw = str(row[url_col]) if pd.notna(row[url_col]) else ''
            homepage_url = homepage_url_raw.strip()
            
            if not homepage_url or homepage_url == 'nan':
                print(f"({index+1}/{len(df)}) 跳过空URL")
                continue
            
            # 检查是否已处理
            if homepage_url in processed_urls:
                skipped_count += 1
                print(f"({index+1}/{len(df)}) ⏭️  跳过已处理: {homepage_url[:60]}...")
                continue
            
            print(f"({index+1}/{len(df)}) 🔍 处理URL: {homepage_url}")
            
            # 提取详细信息
            details = extract_author_details(homepage_url, driver)
            
            # 写入CSV（追加模式）
            output_df = pd.DataFrame([details])
            output_df.to_csv(OUTPUT_CSV, mode='a', index=False, 
                            encoding='utf-8-sig', header=need_header)
            need_header = False
            
            processed_urls.add(homepage_url)
            total_processed += 1
            success_count += 1
            
            print(f"  💾 已保存到文件\n")
            
            # 添加延时
            time.sleep(3)
        
        # 处理完成
        print("\n" + "=" * 50)
        print(f"✅ 处理完成！")
        print(f"📊 跳过已处理URL: {skipped_count} 个")
        print(f"📊 本次新处理URL: {total_processed} 个")
        print(f"📊 累计已处理URL: {len(processed_urls)} 个")
        print(f"💾 结果已保存到: {OUTPUT_CSV}")
        print("=" * 50)
        
    except Exception as e:
        print(f"处理文件时发生错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n正在关闭浏览器...")
        driver.quit()


if __name__ == '__main__':
    main()

