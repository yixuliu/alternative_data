#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import os
from pathlib import Path

# 获取当前目录
current_dir = Path(__file__).parent

# 存储所有数据
all_data = []
seen_urls = set()
duplicate_count = 0

# 读取所有JSON和JSONL文件
for file_path in current_dir.glob("*.json*"):
    if file_path.name == "merged_data.json":  # 跳过输出文件
        continue
    
    print(f"正在处理: {file_path.name}")
    
    try:
        if file_path.suffix == ".json":
            # 读取JSON文件（数组格式）
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "URL" in item:
                            url = item["URL"]
                            if url not in seen_urls:
                                seen_urls.add(url)
                                all_data.append(item)
                            else:
                                duplicate_count += 1
                elif isinstance(data, dict) and "URL" in data:
                    url = data["URL"]
                    if url not in seen_urls:
                        seen_urls.add(url)
                        all_data.append(data)
                    else:
                        duplicate_count += 1
        
        elif file_path.suffix == ".jsonl":
            # 读取JSONL文件（每行一个JSON对象）
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            item = json.loads(line)
                            if isinstance(item, dict) and "URL" in item:
                                url = item["URL"]
                                if url not in seen_urls:
                                    seen_urls.add(url)
                                    all_data.append(item)
                                else:
                                    duplicate_count += 1
                        except json.JSONDecodeError:
                            continue
    except Exception as e:
        print(f"处理 {file_path.name} 时出错: {e}")
        continue

# 保存合并后的数据
output_file = current_dir / "merged_data.json"
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(all_data, f, ensure_ascii=False, indent=2)

# 打印统计信息
print(f"\n合并完成！")
print(f"重复内容数量: {duplicate_count}")
print(f"合并后总条数: {len(all_data)}")
print(f"输出文件: {output_file}")

