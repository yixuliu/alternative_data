#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google News 新闻爬虫
根据关键词和条数爬取新闻，输出 JSONL 格式
"""

import requests
from bs4 import BeautifulSoup
import time
import json
import re
import sys
from datetime import datetime, timedelta
from urllib.parse import urlparse, parse_qs


class NewsCrawler:
    """新闻爬虫类"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.base_url = "https://www.google.com/search"
        self.seen_urls = set()  # 用于去重
    
    def crawl(self, keyword, target_count):
        """
        爬取新闻
        
        Args:
            keyword: 搜索关键词
            target_count: 目标爬取条数
        
        Returns:
            list: 新闻列表
        """
        results = []
        page = 0
        
        print(f"开始爬取关键词: {keyword}, 目标条数: {target_count}")
        
        while len(results) < target_count:
            print(f"正在爬取第 {page + 1} 页...")
            
            # 获取搜索结果
            news_items = self._fetch_page(keyword, page)
            
            if not news_items:
                print("没有更多结果了")
                break
            
            # 处理每条新闻
            for item in news_items:
                if len(results) >= target_count:
                    break
                
                news = self._process_news_item(item)
                if news and news['URL'] not in self.seen_urls:
                    # 获取完整内容
                    content = self._fetch_content(news['URL'])
                    if content:
                        news['Content'] = content
                        results.append(news)
                        self.seen_urls.add(news['URL'])
                        print(f"✓ [{len(results)}/{target_count}] {news['Title'][:50]}...")
                    time.sleep(1)  # 避免请求过快
            
            page += 1
            time.sleep(2)  # 页面间延迟
        
        print(f"\n爬取完成！共获取 {len(results)} 条新闻")
        return results
    
    def _fetch_page(self, keyword, page):
        """获取一页搜索结果"""
        try:
            params = {
                'q': keyword,
                'tbm': 'nws',
                'start': page * 10,
                'hl': 'zh-CN',
                'gl': 'CN'
            }
            
            response = requests.get(self.base_url, params=params, headers=self.headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 尝试多种可能的Google News结果选择器（参考 google_new_p3.py）
            news_items = soup.find_all('div', class_='g')
            
            # 如果方法1没找到，尝试其他选择器
            if not news_items:
                news_items = soup.find_all('div', {'data-ved': True})
            
            if not news_items:
                # 查找包含链接的div
                news_items = soup.find_all('div', class_=lambda x: x and ('result' in x.lower() or 'news' in x.lower()))
            
            if not news_items:
                # 查找所有包含h3标题的div
                all_divs = soup.find_all('div')
                news_items = [div for div in all_divs if div.find('h3')]
            
            return news_items
            
        except Exception as e:
            print(f"获取页面失败: {e}")
            return []
    
    def _process_news_item(self, item):
        """处理单个新闻项，提取基本信息"""
        try:
            # 提取标题和链接
            title_elem = item.find('h3')
            if not title_elem:
                return None
            
            title = title_elem.get_text().strip()
            if not title:
                return None
            
            # 查找链接 - 尝试多种方式（参考 google_new_p3.py）
            link_elem = None
            
            # 方法1: 在标题元素内查找
            if title_elem.parent and title_elem.parent.name == 'a':
                link_elem = title_elem.parent
            else:
                # 方法2: 在item内查找所有链接
                links = item.find_all('a', href=True)
                for link in links:
                    href = link.get('href', '')
                    if href and (href.startswith('http') or href.startswith('/url')):
                        link_elem = link
                        break
            
            if not link_elem:
                return None
            
            url = link_elem.get('href', '')
            if not url:
                return None
            
            # 清理Google重定向URL（参考 google_new_p3.py）
            if url.startswith('/url?q='):
                url = url.split('/url?q=')[1].split('&')[0]
            elif url.startswith('/url?'):
                # 处理 /url?url=... 格式
                parsed = urlparse(url)
                params = parse_qs(parsed.query)
                if 'url' in params:
                    url = params['url'][0]
                elif 'q' in params:
                    url = params['q'][0]
            
            # 确保URL是有效的，并且不是Google内部链接
            if not url.startswith('http'):
                return None
            
            # 过滤掉Google内部链接（maps, images等）
            if any(domain in url for domain in ['maps.google', 'images.google', 'translate.google', 'webcache.googleusercontent']):
                return None
            
            # 提取来源
            source = ""
            for selector in [('span', 'f'), ('span', 'fG8Fp'), ('div', 'fG8Fp')]:
                elem = item.find(selector[0], class_=selector[1])
                if elem:
                    source = elem.get_text().strip()
                    break
            
            # 提取日期
            date_str = self._extract_date(item)
            
            return {
                'URL': url,
                'Title': title,
                'Date': date_str,
                'Source': source or '未知',
                'Content': ''  # 稍后填充
            }
            
        except Exception as e:
            return None
    
    def _extract_date(self, item):
        """从新闻项中提取日期，格式化为 YYYY-MM-DD"""
        try:
            # 尝试从各种元素中提取日期
            date_text = ""
            for selector in [('span', 'f'), ('span', 'fG8Fp'), ('div', 'fG8Fp')]:
                elem = item.find(selector[0], class_=selector[1])
                if elem:
                    date_text = elem.get_text()
                    break
            
            # 尝试解析日期
            # 匹配 "X小时前"、"X天前"、"X月X日" 等格式
            if '小时前' in date_text or '分钟前' in date_text:
                return datetime.now().strftime('%Y-%m-%d')
            
            if '天前' in date_text:
                days = int(re.search(r'(\d+)', date_text).group(1))
                date = datetime.now() - timedelta(days=days)
                return date.strftime('%Y-%m-%d')
            
            # 尝试匹配 "2024年1月1日" 或 "2024-01-01" 等格式
            date_patterns = [
                r'(\d{4})年(\d{1,2})月(\d{1,2})日',
                r'(\d{4})-(\d{1,2})-(\d{1,2})',
                r'(\d{1,2})月(\d{1,2})日',
            ]
            
            for pattern in date_patterns:
                match = re.search(pattern, date_text)
                if match:
                    if len(match.groups()) == 3:
                        year, month, day = match.groups()
                        if len(year) == 4:
                            return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
                    elif len(match.groups()) == 2:
                        # 只有月日，使用当前年份
                        month, day = match.groups()
                        year = datetime.now().year
                        return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
            
            # 如果无法解析，返回当前日期
            return datetime.now().strftime('%Y-%m-%d')
            
        except:
            return datetime.now().strftime('%Y-%m-%d')
    
    def _fetch_content(self, url):
        """获取文章完整内容"""
        try:
            response = requests.get(url, headers=self.headers, timeout=10, allow_redirects=True)
            response.raise_for_status()
            
            # 检测编码（参考 google_new_p3.py）
            if response.encoding is None or response.encoding == 'ISO-8859-1':
                response.encoding = response.apparent_encoding or 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 移除不需要的元素
            for tag in soup(["script", "style", "nav", "header", "footer", "aside", "iframe"]):
                tag.decompose()
            
            # 尝试多种常见的文章内容选择器（参考 google_new_p3.py）
            content_selectors = [
                'article',
                '[role="article"]',
                '.article-content',
                '.article-body',
                '.post-content',
                '.entry-content',
                '.content',
                'main',
                '.main-content',
                '#article-body',
                '#content',
                '.story-body',
                '.article-text'
            ]
            
            content = ""
            for selector in content_selectors:
                elements = soup.select(selector)
                if elements:
                    content = ' '.join([elem.get_text(separator=' ', strip=True) for elem in elements])
                    if len(content) > 200:  # 如果内容足够长，使用它
                        break
            
            # 如果上面的选择器都没找到足够的内容，尝试获取所有段落
            if len(content) < 200:
                paragraphs = soup.find_all('p')
                content = ' '.join([p.get_text(separator=' ', strip=True) for p in paragraphs])
            
            # 清理文本：移除多余的空白字符
            content = re.sub(r'\s+', ' ', content).strip()
            
            return content if len(content) > 50 else ""  # 至少50字符才认为有效
            
        except Exception as e:
            return ""
    
    def save_jsonl(self, results, keyword):
        """保存为 JSONL 格式"""
        filename = f"{keyword}_News_Raw.jsonl"
        
        with open(filename, 'w', encoding='utf-8') as f:
            for news in results:
                f.write(json.dumps(news, ensure_ascii=False) + '\n')
        
        print(f"结果已保存到: {filename}")
        return filename


def main():
    """主函数"""
    print("=" * 60)
    print("Google News 新闻爬虫")
    print("=" * 60)
    
    # 获取用户输入
    keyword = input("请输入搜索关键词: ").strip()
    if not keyword:
        print("关键词不能为空！")
        return
    
    try:
        target_count = int(input("请输入要爬取的条数: ").strip())
        if target_count <= 0:
            print("条数必须大于0！")
            return
    except ValueError:
        print("请输入有效的数字！")
        return
    
    # 开始爬取
    crawler = NewsCrawler()
    results = crawler.crawl(keyword, target_count)
    
    # 保存结果
    if results:
        crawler.save_jsonl(results, keyword)
        
        # 统计信息
        with_content = sum(1 for r in results if r.get('Content', ''))
        print(f"\n统计信息:")
        print(f"  总条数: {len(results)}")
        print(f"  有完整内容: {with_content} ({with_content/len(results)*100:.1f}%)")
    else:
        print("未获取到任何新闻！")


if __name__ == '__main__':
    main()

