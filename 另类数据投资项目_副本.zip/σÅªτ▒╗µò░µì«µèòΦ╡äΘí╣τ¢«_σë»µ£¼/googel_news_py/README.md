# Google News 爬虫与评估工具集

本目录包含一套完整的 Google News 新闻爬取、合并和评估工具链。

## 📁 文件说明

### 1. `google_news_crawler.py` - Google News 新闻爬虫

**功能**：根据关键词和指定条数爬取 Google News 新闻，并提取新闻的标题、链接、日期、来源和完整内容。

**主要特性**：
- 支持关键词搜索
- 自动翻页获取多页结果
- 自动去重（基于 URL）
- 提取新闻完整内容
- 输出 JSONL 格式（每行一个 JSON 对象）

**使用方法**：
```bash
python google_news_crawler.py
```

运行后会提示输入：
- 搜索关键词
- 要爬取的条数

**输出文件**：`{关键词}_News_Raw.jsonl`

**输出格式**：
```json
{
  "URL": "新闻链接",
  "Title": "新闻标题",
  "Date": "YYYY-MM-DD",
  "Source": "新闻来源",
  "Content": "新闻完整内容"
}
```

---

### 2. `merge_json.py` - JSON/JSONL 文件合并工具

**功能**：自动合并当前目录下所有 JSON 和 JSONL 文件，并自动去重。

**主要特性**：
- 支持 JSON 和 JSONL 两种格式
- 自动去重（基于 URL 字段）
- 跳过输出文件本身（`merged_data.json`）
- 统计重复内容数量

**使用方法**：
```bash
python merge_json.py
```

**输出文件**：`merged_data.json`

**注意事项**：
- 会自动处理当前目录下所有 `.json` 和 `.jsonl` 文件
- 如果文件中的对象没有 `URL` 字段，会被跳过
- 重复的 URL 会被自动过滤

---

### 3. `news_qwen_scorer.py` - 通义千问 VC 评估工具

**功能**：读取 JSON 文件中的新闻数据，使用通义千问 API 进行 VC（风险投资）量化评估。

**主要特性**：
- 使用通义千问 API 进行智能评估
- 5 个核心 VC 评估指标：
  - 领先性得分 (Lead_Score): 1-10 分
  - 商业化成熟度 (Commercial_Maturity): 1-10 分
  - 资金/融资强度 (Funding_Intensity): 1-10 分
  - 净情感值 (Net_Sentiment_Score): -10.0 到 +10.0
  - 整体信心指数 (Overall_Confidence): 1-10 分
- 输出 JSON 和 CSV 两种格式
- 自动重试机制（API 调用失败时）

**配置说明**：
在使用前，需要修改文件中的配置：

```python
# 配置API密钥
DASHSCOPE_API_KEY = "替换为你的API密钥"

# 配置输入输出路径
INPUT_JSON_FILE = "输入JSON文件路径"
OUTPUT_DIR = None  # None表示使用默认目录（输入文件同目录下的qwen_scores文件夹）
```

**使用方法**：
```bash
python news_qwen_scorer.py
```

**输出文件**：
- `qwen_scores/scores_{时间戳}.json` - JSON 格式结果
- `qwen_scores/scores_{时间戳}.csv` - CSV 格式结果

**输出字段**：
- `Company`: 公司名称
- `Source_Type`: 来源类型
- `Metric_1_Lead_Score`: 领先性得分
- `Metric_2_Commercial_Maturity`: 商业化成熟度
- `Metric_3_Funding_Intensity`: 资金/融资强度
- `Metric_4_Net_Sentiment_Score`: 净情感值
- `Metric_5_Overall_Confidence`: 整体信心指数
- `Original_URL`: 原始新闻链接
- `Original_Title`: 原始新闻标题
- `Original_Date`: 原始新闻日期
- `Original_Source`: 原始新闻来源
- `Evaluation_Time`: 评估时间戳

---

## 🔄 典型工作流程

1. **爬取新闻**：
   ```bash
   python google_news_crawler.py
   ```
   输入关键词和条数，生成 `{关键词}_News_Raw.jsonl` 文件

2. **合并多个文件**（如果需要）：
   ```bash
   python merge_json.py
   ```
   将多个 JSON/JSONL 文件合并为 `merged_data.json`

3. **评估新闻**：
   修改 `news_qwen_scorer.py` 中的配置：
   - 设置 API 密钥
   - 设置输入文件路径（可以是 `merged_data.json` 或单个 JSONL 文件）
   ```bash
   python news_qwen_scorer.py
   ```
   生成评估结果到 `qwen_scores/` 目录

---

## 📦 依赖安装

```bash
pip install requests beautifulsoup4 dashscope
```

**依赖说明**：
- `requests`: HTTP 请求库
- `beautifulsoup4`: HTML 解析库
- `dashscope`: 阿里云通义千问 API SDK

---

## ⚠️ 注意事项

1. **API 密钥**：使用 `news_qwen_scorer.py` 前必须配置有效的通义千问 API 密钥
2. **网络环境**：爬虫需要能够访问 Google News
3. **请求频率**：代码中已包含延迟机制，避免请求过于频繁
4. **内容长度**：评估工具会自动截断超过 8000 字符的内容
5. **文件格式**：确保 JSON/JSONL 文件格式正确，包含必要的字段（如 `URL`、`Content` 等）

---

## 📝 文件格式要求

### 输入格式（用于评估工具）

JSON 文件应为数组格式，每个元素包含：
```json
[
  {
    "URL": "新闻链接",
    "Title": "新闻标题",
    "Date": "日期",
    "Source": "来源",
    "Content": "新闻内容"
  }
]
```

或 JSONL 格式（每行一个 JSON 对象）：
```jsonl
{"URL": "...", "Title": "...", "Content": "..."}
{"URL": "...", "Title": "...", "Content": "..."}
```

---

## 🐛 常见问题

1. **爬虫无法获取结果**：可能是 Google 页面结构变化，需要更新选择器
2. **API 调用失败**：检查 API 密钥是否正确，网络是否正常
3. **合并文件时出错**：确保文件格式正确，包含 `URL` 字段
4. **评估结果为空**：检查输入文件中的 `Content` 字段是否有内容

---

## 📄 许可证

本工具集仅供学习和研究使用。

