#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通义千问打分评估工具
读取JSON文件，使用通义千问API进行VC量化评估，输出JSON和CSV结果
"""

import os
import json
import csv
import time
from datetime import datetime
from pathlib import Path
import dashscope
from dashscope import Generation

# ==================== 配置区域 ====================
# 配置API密钥
DASHSCOPE_API_KEY = "替换"
dashscope.api_key = DASHSCOPE_API_KEY

# 配置输入输出路径（直接在这里修改）
INPUT_JSON_FILE = "/Users/yvesliu/Desktop/test/gaorong/market_analyse/all_media_data_json/pika_merged_data.json"  # 输入JSON文件路径
OUTPUT_DIR = None  # 输出目录，None表示使用默认目录（输入文件同目录下的qwen_scores文件夹）
# ==================================================

# VC评估提示词模板
VC_PROMPT_TEMPLATE = """你是一位专业的风险投资（VC）分析师，你的目标是快速、客观地对一家科技公司进行量化评估。请根据以下提供的【新闻/文章全文】，严格遵守 5 个核心指标，进行量化打分。

**【新闻/文章全文】**：
{content}

**【VC 核心量化评估指标及要求】**：
1. 领先性得分 (Lead_Score): 1-10 分。评估技术/产品相对于现有主流方案的差异和超越程度。
2. 商业化成熟度 (Commercial_Maturity): 1-10 分。基于产品阶段、客户或营收信号，评估其接近大规模营收的程度。
3. 资金/融资强度 (Funding_Intensity): 1-10 分。评估文本中提及的融资额度、客户规模或母公司背景所体现的资金实力。
4. 净情感值 (Net_Sentiment_Score): -10.0 到 +10.0。评估文本的整体情绪倾向（负面风险 vs. 正面突破）。
5. 整体信心指数 (Overall_Confidence): 1-10 分。基于前 4 个指标的综合评估，给出最终的投资机会打分。

**【输出要求】**：
请**严格且仅以以下 JSON 格式**输出你的评估结果，**所有分数必须是浮点数**（例如 7.5, 9.0, -5.5）：

{{
  "Company": "[公司名称]",
  "Source_Type": "[新闻/文章/研报]",
  "Metric_1_Lead_Score": [浮点数],
  "Metric_2_Commercial_Maturity": [浮点数],
  "Metric_3_Funding_Intensity": [浮点数],
  "Metric_4_Net_Sentiment_Score": [浮点数],
  "Metric_5_Overall_Confidence": [浮点数]
}}"""


def call_qwen_api(prompt, max_retries=3):
    """调用通义千问API"""
    for attempt in range(max_retries):
        try:
            response = Generation.call(
                model='qwen-plus',
                prompt=prompt,
                temperature=0.7,
                max_tokens=2000,
                top_p=0.9
            )
            
            if response.status_code == 200:
                return response.output.text
            else:
                print(f"⚠️  API调用失败 (状态码: {response.status_code}): {response.message}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避
        except Exception as e:
            print(f"❌ API调用异常: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
    
    return None


def extract_json_from_text(text):
    """从文本中提取JSON内容"""
    import re
    
    # 方法1: 尝试找到包含Company字段的JSON对象
    json_match = re.search(r'\{[^{}]*(?:"Company"|"Metric_1")[^{}]*\}', text, re.DOTALL)
    if json_match:
        json_str = json_match.group(0)
        try:
            result = json.loads(json_str)
            # 验证是否包含必要的字段
            if 'Company' in result or 'Metric_1_Lead_Score' in result:
                return result
        except json.JSONDecodeError:
            pass
    
    # 方法2: 尝试提取代码块中的JSON
    code_block_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if code_block_match:
        json_str = code_block_match.group(1)
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass
    
    # 方法3: 尝试提取第一个完整的JSON对象
    json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text, re.DOTALL)
    if json_match:
        json_str = json_match.group(0)
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass
    
    return None


def evaluate_article(article_data):
    """评估单篇文章"""
    # 构建内容文本
    content = article_data.get('Content', '')
    if not content:
        print("⚠️  文章内容为空，跳过")
        return None
    
    # 限制内容长度（避免超出token限制）
    if len(content) > 8000:
        content = content[:8000] + "..."
    
    # 构建提示词
    prompt = VC_PROMPT_TEMPLATE.format(content=content)
    
    # 调用API
    print(f"📊 正在评估: {article_data.get('Title', '未知标题')[:50]}...")
    response_text = call_qwen_api(prompt)
    
    if not response_text:
        print("❌ API调用失败")
        return None
    
    # 提取JSON结果
    result = extract_json_from_text(response_text)
    
    if result:
        # 添加原始文章信息
        result['Original_URL'] = article_data.get('URL', '')
        result['Original_Title'] = article_data.get('Title', '')
        result['Original_Date'] = article_data.get('Date', '')
        result['Original_Source'] = article_data.get('Source', '')
        # 添加评估时间戳（JSON输出的具体时间）
        result['Evaluation_Time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return result
    else:
        print(f"⚠️  无法解析JSON结果，原始响应: {response_text[:200]}...")
        return None


def process_json_file(input_file, output_dir=None):
    """处理JSON文件"""
    input_path = Path(input_file)
    if not input_path.exists():
        print(f"❌ 文件不存在: {input_file}")
        return
    
    # 设置输出目录
    if output_dir is None:
        output_dir = input_path.parent / "qwen_scores"
    else:
        output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # 读取输入JSON
    print(f"📂 读取文件: {input_file}")
    with open(input_path, 'r', encoding='utf-8') as f:
        articles = json.load(f)
    
    print(f"📰 共找到 {len(articles)} 篇文章")
    
    # 处理每篇文章
    results = []
    for i, article in enumerate(articles, 1):
        print(f"\n[{i}/{len(articles)}] ", end="")
        result = evaluate_article(article)
        if result:
            results.append(result)
        
        # 避免API调用过于频繁
        if i < len(articles):
            time.sleep(1)
    
    # 保存JSON结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_output = output_dir / f"scores_{timestamp}.json"
    with open(json_output, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n✅ JSON结果已保存: {json_output}")
    
    # 保存CSV结果
    csv_output = output_dir / f"scores_{timestamp}.csv"
    if results:
        # 定义CSV列
        fieldnames = [
            'Company', 'Source_Type',
            'Metric_1_Lead_Score', 'Metric_2_Commercial_Maturity',
            'Metric_3_Funding_Intensity', 'Metric_4_Net_Sentiment_Score',
            'Metric_5_Overall_Confidence',
            'Original_URL', 'Original_Title', 'Original_Date', 'Original_Source',
            'Evaluation_Time'  # 评估时间戳（JSON输出的具体时间）
        ]
        
        with open(csv_output, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for result in results:
                writer.writerow(result)
        print(f"✅ CSV结果已保存: {csv_output}")
    
    print(f"\n📊 处理完成: 成功评估 {len(results)}/{len(articles)} 篇文章")
    return results


def main():
    """主函数"""
    # 直接使用文件顶部配置的路径
    process_json_file(INPUT_JSON_FILE, OUTPUT_DIR)


if __name__ == "__main__":
    main()

